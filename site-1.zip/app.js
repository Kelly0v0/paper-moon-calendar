'use strict';

const assets = window.paperAssets;
const $ = id => document.getElementById(id);
const app = document.querySelector('.app');
const art = $('art');
const WIDTH = art.width;
const HEIGHT = art.height;
const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const defaultColors = { ink: '#493021', wine: '#961622' };
const cache = new Map();
const defaultMonthTitle = {
  id: 'title', kind: 'art', style: 'ink', color: defaultColors.ink, x: 512, y: 460, width: 650, angle: 0
};

const styledTemplates = [
  {
    name: '薄荷来信', category: '常规', group: 'calendars', background: '薄荷野餐', cover: 'collage',
    date: { style: 'fineDates', x: 512, y: 1210, width: 810, color: '#3E5847' },
    heading: { kind: 'art', style: 'wine', x: 512, y: 281, width: 550, color: '#873D51' },
    caption: { text: '薄 荷 来 信', font: 'fang', x: 512, y: 927, width: 38, color: '#3E5847' },
    coverTitle: { text: '薄荷来信', font: 'fang', x: 512, y: 690, width: 123, color: '#873D51' },
    coverCaption: { text: '二〇二七 · 手作台历', font: 'song', x: 512, y: 860, width: 42, color: '#3E5847' },
    stickers: [
      ['stickers-dot-cosmos.png', 267, 523, 198, -13, '#53654A'],
      ['stickers-dot-bow.png', 753, 549, 192, 13, '#9C5465'],
      ['stickers-stars-02.webp', 126, 945, 83, -11],
      ['stickers-stars-27.webp', 888, 943, 79, 11]
    ],
    coverStickers: [
      ['stickers-dot-cosmos.png', 338, 426, 188, -13, '#53654A'],
      ['stickers-dot-bow.png', 661, 421, 179, 13, '#9C5465'],
      ['stickers-lace-05.webp', 719, 1126, 170, -8]
    ]
  },
  {
    name: '雾紫梦游', category: '纯色', group: 'solids', background: '雾香芋',
    date: { style: 'inkDates', x: 512, y: 1228, width: 805, color: '#483654' },
    heading: { kind: 'art', style: 'ink', x: 512, y: 331, width: 595, color: '#483654' },
    caption: { text: '雾 紫 梦 游', font: 'song', x: 512, y: 160, width: 37, color: '#483654' },
    coverTitle: { text: '雾紫梦游', font: 'song', x: 512, y: 758, width: 115, color: '#483654' },
    coverCaption: { text: '二〇二七 · 手作台历', font: 'fang', x: 512, y: 1222, width: 45, color: '#483654' },
    stickers: [
      ['stickers-dot-moon.png', 246, 620, 225, -13, '#66527B'],
      ['stickers-lamb-03.webp', 723, 794, 307, -5, '#483654'],
      ['stickers-stars-31.webp', 762, 541, 87, 16],
      ['stickers-stars-36.webp', 421, 760, 73, -12],
      ['stickers-stars-29.webp', 333, 900, 61, 12]
    ],
    coverStickers: [
      ['stickers-year-05.webp', 512, 426, 525, -5],
      ['stickers-dot-moon.png', 215, 585, 154, -13, '#66527B'],
      ['stickers-stars-36.webp', 777, 601, 131, 15],
      ['stickers-lamb-03.webp', 507, 1003, 322, -4, '#483654']
    ]
  },
  {
    name: '午夜放映', category: '海报', group: 'posters', background: '蓝莓放映',
    cover: 'poster',
    date: { style: 'dates', x: 512, y: 1197, width: 699, color: '#3E2F52' },
    heading: { kind: 'art', style: 'wine', x: 389, y: 448, width: 561, color: '#FFF0B7' },
    caption: { text: '午 夜 放 映', font: 'song', x: 355, y: 230, width: 51, color: '#FFF0B7' },
    coverTitle: { text: '午夜放映', font: 'song', x: 512, y: 731, width: 130, color: '#FFF0B7' },
    coverCaption: { text: '二〇二七 · 手作台历', font: 'fang', x: 512, y: 865, width: 43, color: '#FFF0B7' },
    stickers: [
      ['stickers-retro-new-01.webp', 575, 206, 124, 10],
      ['stickers-retro-new-04.webp', 305, 757, 215, -12],
      ['stickers-retro-new-05.webp', 570, 889, 252, 13]
    ],
    coverStickers: [
      ['stickers-year-04.webp', 508, 448, 565, -8],
      ['stickers-retro-new-04.webp', 288, 1031, 196, -10],
      ['stickers-retro-new-05.webp', 691, 1072, 248, 12]
    ]
  }
];

function composeTemplate(preset, page) {
  const isCover = page === COVER_PAGE;
  const group = preset.group;
  const template = assets[group].findIndex(asset => isCover && preset.cover
    ? asset.coverStyle === preset.cover : asset.name === preset.background);
  const text = fields => Object.assign({ kind: 'text', angle: 0 }, fields);
  const layers = (isCover ? preset.coverStickers : preset.stickers).map(([file, x, y, width, angle, color]) => ({
    kind: 'sticker', stickerSrc: assets.stickers.find(asset => asset.src.split('/').pop() === file).src,
    x, y, width, angle, color
  }));
  if (isCover) layers.push(text(preset.coverTitle), text(preset.coverCaption));
  else {
    const title = Object.assign({ id: 'title', angle: 0 }, preset.heading);
    if (preset.maxTitleHeight) {
      const image = assets[title.style][page];
      title.width = Math.min(title.width, Math.floor(preset.maxTitleHeight * image.w / image.h));
    }
    if (preset.monthlyOnly) layers.unshift(title, ...preset.captions.map(text));
    else layers.push(text(preset.caption), title);
    for (const [file, x, y, width, angle] of preset.edges || []) {
      const edge = assets.edges.find(item => item.src.split('/').pop() === file);
      layers.push({ kind: 'edge', edgeSrc: edge.src, x, y, width, angle });
    }
  }
  const project = {
    group, template, isCover,
    layers: layers.map((layer, index) => Object.assign({ id: 'template-layer-' + index, templatePart: true }, layer))
  };
  if (!isCover) {
    if (preset.monthlyOnly) project.borderIndex = preset.borderIndex;
    if (preset.photoSlots) project.photoSlots = preset.photoSlots.map(slot => Object.assign({}, slot));
    const { style, x, y, width, color } = preset.date;
    project.dateStyle = style;
    project[datePositionKey(project)] = { x, y, width, color, angle: 0 };
  }
  return project;
}


let projects = monthNames.map((_, index) => ({ group: 'calendars', template: index % assets.calendars.length, layers: [
  Object.assign({}, defaultMonthTitle)
] }));
const COVER_PAGE = -1;
const coverStyles = [['calendars', 'collage'], ['posters', 'poster'], ['solids', 'solid']];
let coverProject = {
  group: 'calendars', template: assets.calendars.findIndex(asset => asset.coverStyle === 'collage'), isCover: true, layers: []
};

function isUnusedCoverTitle(layer) {
  const preset = [
    { id: 'cover-year', kind: 'text', text: '2027', x: 512, y: 690, width: 172, angle: 0 },
    { id: 'cover-caption', kind: 'text', text: '手作台历', x: 512, y: 840, width: 52, angle: 0 }
  ].find(item => item.id === layer.id);
  return !!preset && Object.keys(layer).length === Object.keys(preset).length &&
    Object.keys(preset).every(key => layer[key] === preset[key]);
}
let month = COVER_PAGE;
let view = 'edit';
let tool = 'layout';
let selected = null;
let photoDraft = null;
let frame = 0;
let toastTimer;
let saveTimer;
let db;
let storageProblem = false;
const current = () => month === COVER_PAGE ? coverProject : projects[month];
const DATE_LAYER = 'calendar-dates';
const dateStyles = [['dates', '基础日期'], ['fineDates', '细笔手写'], ['inkDates', '黑墨手写']];
const showsDates = project => !project.isCover && project.dateVisible !== false;
const dateAsset = project => assets[project.dateStyle] || assets.dates;
const DATE_DEFAULT = { x: 512, y: 1239, width: 952, angle: 0 };
const dateHeight = width => width * 430 / 952;
const posterDateCards = [
  [630, 1167, 604, '#EAF0ED', '#213947'],
  [383, 1030, 584, '#FBEDD8', '#523A39'],
  [512, 970, 650, '#FAE5D8', '#732F43'],
  [568, 1130, 632, '#EDF1DC', '#30544F'],
  [512, 1204, 632, '#F1DEE4', '#4C2E50'],
  [432, 1160, 622, '#F5E4BC', '#60432D'],
  [598, 1145, 602, '#F7E4DE', '#653C49'],
  [535, 1188, 635, '#E3EAF2', '#2F415B'],
  [576, 1170, 620, '#F2EFCF', '#44513A'],
  [417, 1160, 620, '#EDE1F2', '#433751'],
  [535, 1160, 624, '#F8E4D4', '#603B35'],
  [512, 1157, 650, '#ECEDDA', '#3B4F43']
];

function datePositionKey(project) {
  return project.group === 'posters' ? 'posterDatePosition' : 'datePosition';
}

function posterDateCard(project) {
  return posterDateCards[project.template] || posterDateCards[0];
}

function defaultDatePosition(project) {
  if (project.group !== 'posters') return DATE_DEFAULT;
  const [x, y, width] = posterDateCard(project);
  return { x, y, width, angle: 0 };
}

function datePosition(project) {
  return project[datePositionKey(project)] || defaultDatePosition(project);
}

const dateCardPadding = width => Math.max(9, width * .035);

function drawPosterDateCard(ctx, project, width, height) {
  const pad = dateCardPadding(width);
  const x = -width / 2 - pad, y = -height / 2 - pad;
  const w = width + pad * 2, h = height + pad * 2;
  const radius = Math.min(18, w / 12, h / 12);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
  ctx.fillStyle = posterDateCard(project)[3];
  ctx.fill();
  ctx.strokeStyle = 'rgba(59, 43, 40, .30)';
  ctx.lineWidth = 2;
  ctx.stroke();
}
const layerOrderActions = [['raise', 'top'], ['layer-up', 'up'], ['layer-down', 'down'], ['layer-bottom', 'bottom']];

function dateStackIndex(project) {
  return Number.isInteger(project.dateLayerIndex)
    ? Math.max(0, Math.min(project.layers.length, project.dateLayerIndex))
    : project.layers.length;
}

function layerOrder(project) {
  const ids = project.layers.map(layer => layer.id);
  if (showsDates(project)) ids.splice(dateStackIndex(project), 0, DATE_LAYER);
  return ids;
}

function moveLayerInOrder(project, id, action) {
  const ids = layerOrder(project);
  const from = ids.indexOf(id);
  const to = action === 'top' ? ids.length - 1 : action === 'bottom' ? 0 : from + (action === 'up' ? 1 : -1);
  if (from < 0 || to < 0 || to >= ids.length || from === to) return false;
  ids.splice(from, 1);
  ids.splice(to, 0, id);
  const dateIndex = ids.indexOf(DATE_LAYER);
  if (dateIndex === ids.length - 1) delete project.dateLayerIndex;
  else if (dateIndex !== -1) project.dateLayerIndex = dateIndex;
  const byId = new Map(project.layers.map(layer => [layer.id, layer]));
  project.layers = ids.filter(key => key !== DATE_LAYER).map(key => byId.get(key));
  return true;
}

function defaultDateColor(project) {
  if (project.group === 'posters') return posterDateCard(project)[4];
  const background = assets[project.group][project.template];
  if (background.color === '#000000' || background.color === '#455563') return '#F3EEE3';
  return '';
}
const activeLayer = () => {
  if (photoDraft) return photoDraft.layer;
  if (selected === DATE_LAYER && showsDates(current())) {
    const project = current();
    const key = datePositionKey(project);
    return project[key] || (project[key] = Object.assign({}, defaultDatePosition(project)));
  }
  return current().layers.find(layer => layer.id === selected);
};

function keepDateOnPaper(position) {
  const a = (position.angle || 0) * Math.PI / 180;
  const w = position.width * photoStretch(position, 'stretchX');
  const h = dateHeight(position.width) * photoStretch(position, 'stretchY');
  const pad = current().group === 'posters' ? dateCardPadding(w) * 2 : 0;
  const halfWidth = Math.min(WIDTH / 2, (Math.abs(Math.cos(a)) * (w + pad) + Math.abs(Math.sin(a)) * (h + pad)) / 2);
  const halfHeight = Math.min(HEIGHT / 2, (Math.abs(Math.sin(a)) * (w + pad) + Math.abs(Math.cos(a)) * (h + pad)) / 2);
  position.x = Math.round(Math.max(halfWidth, Math.min(WIDTH - halfWidth, position.x)));
  position.y = Math.round(Math.max(halfHeight, Math.min(HEIGHT - halfHeight, position.y)));
}

function toast(message) {
  $('toast').textContent = message;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3100);
}

function storage() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('paper-moon-2027', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('design');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function reportStorage() {
  if (!storageProblem) toast('无法在此浏览器保存进度，请先保存图片。');
  storageProblem = true;
}

function readDesignRecord(key) {
  if (!db) return Promise.resolve(null);
  return new Promise((resolve, reject) => {
    const request = db.transaction('design').objectStore('design').get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function writeDesignCheckpoint(snapshot) {
  if (!db) return Promise.resolve(false);
  return new Promise((resolve, reject) => {
    const tx = db.transaction('design', 'readwrite');
    tx.oncomplete = () => resolve(true);
    tx.onabort = () => reject(tx.error);
    tx.objectStore('design').put(snapshot, 'checkpoint');
  });
}

function readDesignCheckpoint() {
  return readDesignRecord('checkpoint');
}

function persist() {
  if (!db) return;
  try {
    const tx = db.transaction('design', 'readwrite');
    tx.objectStore('design').put({ projects, coverProject, month }, 'workspace');
    tx.onabort = reportStorage;
  } catch { reportStorage(); }
}

function changed(trackHistory = true) {
  if (photoDraft) {
    const draft = photoDraft;
    if (!draft.renderPending) {
      draft.renderPending = true;
      requestAnimationFrame(() => {
        draft.renderPending = false;
        if (photoDraft === draft) renderArt();
      });
    }
    return;
  }
  drawPhotoSlots();
  if (trackHistory) {
    if (gesture || handleDrag) motionPage = month;
    else recordDesignChange();
  }
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 180);
  renderArt();
}

function picture(key) {
  if (cache.has(key)) return cache.get(key);
  const img = new Image();
  const pending = new Promise(resolve => {
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = key instanceof Blob ? URL.createObjectURL(key) : key;
  }).then(result => {
    if (key instanceof Blob) URL.revokeObjectURL(img.src);
    if (!result) cache.delete(key);
    return result;
  });
  cache.set(key, pending);
  return pending;
}

function layerAsset(layer, index) {
  if (layer.kind === 'paper') return paperSource(layer.shape);
  if (layer.kind === 'art') return assets[layer.style][index].src;
  if (layer.kind === 'sticker') {
    const entry = assets.stickers.find(sticker => sticker.src === layer.stickerSrc);
    return entry ? entry.src : null;
  }
  if (layer.kind === 'edge') {
    const entry = assets.edges.find(edge => edge.src === layer.edgeSrc);
    return entry ? entry.src : null;
  }
  if (layer.kind === 'photo') return layer.blob;
  return null;
}

const textFaces = {
  song: '纸月宋体',
  fang: '纸月仿宋'
};
const loadedTextFaces = new Map();

function textFont(layer) {
  const face = textFaces[layer.font];
  if (!face) return `700 ${layer.width}px "Microsoft YaHei", sans-serif`;
  const fallback = layer.font === 'fang' ? 'FangSong, STFangsong, "纸月宋体", "Noto Serif CJK SC", "Songti SC"' :
    '"Noto Serif SC", "Noto Serif CJK SC", "Songti SC", SimSun';
  return `400 ${layer.width}px "${face}", ${fallback}, "SimSun-ExtB", "SimSun-ExtG", serif`;
}

function prepareTextFaces(layers) {
  if (!document.fonts || typeof document.fonts.load !== 'function') return Promise.resolve();
  const faces = new Set();
  for (const layer of layers) {
    if (layer.kind !== 'text' || !textFaces[layer.font]) continue;
    faces.add(textFaces[layer.font]);
    if (layer.font === 'fang') faces.add(textFaces.song);
  }
  return Promise.all(Array.from(faces, face => {
    if (!loadedTextFaces.has(face)) {
      loadedTextFaces.set(face, document.fonts.load('16px "' + face + '"', '纸月').catch(() => []));
    }
    return loadedTextFaces.get(face);
  }));
}

const paperStyles = [
  ['rect', '矩形', '#FAF3E5'],
  ['zigzag', '锯齿边', '#F8EEDE'],
  ['wave', '波浪边', '#FFF8E9'],
  ['rounded', '圆角', '#F0EAE1']
];

function paperSource(shape) {
  const selectedShape = paperStyles.find(entry => entry[0] === shape);
  return './assets/paper-cutouts/' + (selectedShape ? selectedShape[0] : 'rect') + '.png';
}

function paperPicker() {
  const list = document.createElement('div');
  list.className = 'paper-shapes';
  for (const [shape, label, color] of paperStyles) {
    const item = button(label, () => {
      addLayer({ kind: 'paper', shape, color, width: 930, x: 512, y: 456 });
      revealEditor($('layer-panel'));
    });
    const sample = document.createElement('span');
    sample.className = 'paper-sample';
    const img = document.createElement('img');
    img.src = paperSource(shape);
    img.alt = '';
    sample.appendChild(img);
    item.insertBefore(sample, item.firstChild);
    list.appendChild(item);
  }
  return list;
}

function layerBox(layer, img, ctx) {
  if (layer.kind === 'text') {
    ctx.font = textFont(layer);
    return { w: Math.min(WIDTH - 50, ctx.measureText(layer.text).width) * photoStretch(layer, 'stretchX'),
      h: layer.width * 1.22 * photoStretch(layer, 'stretchY') };
  }
  const sourceRatio = img ? img.width / img.height : 1;
  const ratio = layer.kind === 'photo' ? photoAspect(layer, sourceRatio) : sourceRatio;
  return { w: layer.width * photoStretch(layer, 'stretchX'),
    h: layer.width / ratio * photoStretch(layer, 'stretchY'), sourceRatio };
}

const tintCache = new WeakMap();

function tintImage(image, color) {
  if (!color) return image;
  const cached = tintCache.get(image);
  if (cached && cached.color === color) return cached.canvas;
  const canvas = document.createElement('canvas');
  canvas.width = image.width;
  canvas.height = image.height;
  const painter = canvas.getContext('2d');
  painter.drawImage(image, 0, 0);
  painter.globalCompositeOperation = 'source-in';
  painter.fillStyle = color;
  painter.fillRect(0, 0, canvas.width, canvas.height);
  tintCache.set(image, { color, canvas });
  return canvas;
}

const stickerOutlines = new WeakMap();

function drawSticker(ctx, layer, image, box) {
  if (layer.outline) {
    let outline = stickerOutlines.get(image);
    if (!outline) {
      const radius = Math.max(2, Math.round(Math.min(image.width, image.height) * .028));
      const pad = radius + 1;
      const mask = effectCanvas(image.width + 2 * pad, image.height + 2 * pad);
      const painter = mask.getContext('2d');
      painter.drawImage(image, pad, pad);
      for (let i = 0; i < 20; i++) {
        const angle = i * Math.PI / 10;
        painter.drawImage(image, pad + Math.cos(angle) * radius, pad + Math.sin(angle) * radius);
      }
      outline = { mask, pad };
      stickerOutlines.set(image, outline);
    }
    const dx = outline.pad * box.w / image.width;
    const dy = outline.pad * box.h / image.height;
    ctx.drawImage(tintImage(outline.mask, layer.outlineColor || '#000000'),
      -box.w / 2 - dx, -box.h / 2 - dy, box.w + 2 * dx, box.h + 2 * dy);
  }
  ctx.drawImage(tintImage(image, layer.color), -box.w / 2, -box.h / 2, box.w, box.h);
}

async function render(target, project, index, canDraw = () => true) {
  const background = assets[project.group][project.template];
  const dates = Object.assign({}, datePosition(project));
  const dateIndex = dateStackIndex(project);
  const dateColor = dates.color || defaultDateColor(project);
  const layers = project.layers.map(layer => ({ ...layer }));
  const border = assets.frames[project.borderIndex];
  const [bg, date, frameImage, ...images] = await Promise.all([
    background.src ? picture(background.src) : null, showsDates(project) ? picture(dateAsset(project)[index].src) : null,
    border && border.src ? picture(border.src) : null,
    ...layers.map(layer => { const source = layerAsset(layer, index); return source ? picture(source) : null; })
  ]);
  await prepareTextFaces(layers);
  if (!canDraw()) return null;
  const ctx = target.getContext('2d');
  ctx.setTransform(target.width / WIDTH, 0, 0, target.height / HEIGHT, 0, 0);
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  ctx.fillStyle = background.color || '#fff1d6';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  if (bg) ctx.drawImage(bg, 0, 0, WIDTH, HEIGHT);
  const boxes = [];
  const drawDates = () => {
    if (!date) return;
    const width = dates.width * photoStretch(dates, 'stretchX');
    const height = dateHeight(dates.width) * photoStretch(dates, 'stretchY');
    const angle = dates.angle || 0;
    ctx.save();
    ctx.translate(dates.x, dates.y);
    ctx.rotate(angle * Math.PI / 180);
    if (project.group === 'posters') drawPosterDateCard(ctx, project, width, height);
    ctx.drawImage(tintImage(date, dateColor), -width / 2, -height / 2, width, height);
    paintDateMarks(ctx, project, index, width, height);
    ctx.restore();
    boxes.push({ id: DATE_LAYER, x: dates.x, y: dates.y, w: width, h: height, angle });
  };
  layers.forEach((layer, i) => {
    if (i === dateIndex) drawDates();
    const img = images[i];
    const box = layerBox(layer, img, ctx);
    ctx.save();
    ctx.translate(layer.x, layer.y);
    ctx.rotate(layer.angle * Math.PI / 180);
    if (layer.kind === 'text') {
      ctx.fillStyle = layer.color || background.ink || '#493021';
      ctx.font = textFont(layer);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.scale(photoStretch(layer, 'stretchX'), photoStretch(layer, 'stretchY'));
      ctx.fillText(layer.text, 0, 0, WIDTH - 50);
    } else if (img && layer.kind === 'paper') {
      ctx.drawImage(tintImage(img, layer.color), -box.w / 2, -box.h / 2, box.w, box.h);
    } else if (img && layer.kind === 'sticker') {
      drawSticker(ctx, layer, img, box);
    } else if (img && layer.kind === 'art') {
      ctx.drawImage(tintImage(img, layer.color), -box.w / 2, -box.h / 2, box.w, box.h);
    } else if (img && layer.kind === 'photo') {
      drawPhoto(ctx, img, layer, box);
    } else if (img) {
      ctx.drawImage(img, -box.w / 2, -box.h / 2, box.w, box.h);
    }
    ctx.restore();
    if (img || layer.kind === 'text') boxes.push({ ...layer, ...box });
  });
  if (dateIndex === layers.length) drawDates();
  if (frameImage) ctx.drawImage(frameImage, 0, 0, WIDTH, HEIGHT);
  return boxes;
}

const flipPaper = $('paper');
const flipOverlay = $('page-flip');
const flipUnder = $('flip-under');
const flipFace = $('flip-face');
const flipLeaf = $('flip-leaf');
const flipShade = $('flip-shade');
let pageFlip = null;
let pageFlipTimer = 0;
let renderedReadPage = null;

function resetPageFlip() {
  clearTimeout(pageFlipTimer);
  pageFlip = null;
  flipOverlay.hidden = true;
  flipOverlay.removeAttribute('data-settling');
  flipUnder.hidden = true;
  flipLeaf.style.transform = '';
  flipShade.style.opacity = '';
}

function paintFlipPose(angle, bend) {
  flipLeaf.style.transform = 'rotateX(' + angle + 'deg) rotateY(' + bend + 'deg)';
  flipShade.style.opacity = String(Math.max(0, Math.sin(angle * Math.PI / 180)) * .40);
}

function copyPaper(from, to) {
  const ctx = to.getContext('2d');
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, to.width, to.height);
  ctx.drawImage(from, 0, 0, to.width, to.height);
}

function beginPageFlip(id, x, y) {
  if (view !== 'read' || pageFlip || renderedReadPage !== month) return false;
  const rect = flipPaper.getBoundingClientRect();
  pageFlip = {
    id, x, y, height: rect.height, time: Date.now(),
    corner: Math.max(-1, Math.min(1, (x - rect.left) / rect.width * 2 - 1)),
    direction: 0, target: null, distance: 0, ready: false, settling: false
  };
  return true;
}

function showFlipTarget(flip, image) {
  if (pageFlip !== flip) return;
  copyPaper(image, flip.direction === 1 ? flipUnder : flipFace);
  flip.ready = true;
  if (!flip.settling) updateFlipPose(flip);
  else if (flip.landWhenReady) landOnFlipTarget(flip);
}

const flipPreviews = new Map();

function preparePreviewPage(index) {
  if (flipPreviews.has(index)) return flipPreviews.get(index);
  const leaf = document.createElement('canvas');
  leaf.width = flipFace.width;
  leaf.height = flipFace.height;
  const project = index === COVER_PAGE ? coverProject : projects[index];
  const pending = render(leaf, project, index).then(() => leaf);
  flipPreviews.set(index, pending);
  return pending;
}

function prefetchPreviewNeighbors() {
  const neighbors = [month - 1, month + 1].filter(index => index >= COVER_PAGE && index < projects.length);
  for (const index of flipPreviews.keys()) {
    if (!neighbors.includes(index) && pageFlip && pageFlip.target === index) continue;
    if (!neighbors.includes(index)) flipPreviews.delete(index);
  }
  for (const index of neighbors) {
    const pending = preparePreviewPage(index);
    pending.catch(() => {
      if (flipPreviews.get(index) === pending) flipPreviews.delete(index);
    });
  }
}

function prepareFlipTarget(flip) {
  const isForward = flip.direction === 1;
  flipUnder.hidden = !isForward;
  if (isForward) copyPaper(art, flipFace);
  preparePreviewPage(flip.target).then(image => showFlipTarget(flip, image)).catch(() => {
    if (pageFlip === flip) resetPageFlip();
  });
}

function updateFlipPose(flip) {
  if (!flip.ready) return;
  const progress = Math.min(1, flip.distance / Math.max(1, flip.height));
  const carried = Math.acos(1 - Math.min(1.84, progress * 2.4)) * 180 / Math.PI;
  const angle = flip.direction === 1 ? carried : 172 - carried;
  paintFlipPose(angle, flip.corner * Math.sin(carried * Math.PI / 180) * 10);
  flipOverlay.hidden = false;
}

function movePageFlip(id, x, y) {
  const flip = pageFlip;
  if (!flip || flip.id !== id || flip.settling) return false;
  const dy = y - flip.y;
  if (!flip.direction) {
    if (Math.abs(dy) < 8 || Math.abs(dy) < Math.abs(x - flip.x)) return false;
    const direction = dy < 0 ? 1 : -1;
    const target = month + direction;
    if (target < COVER_PAGE || target >= projects.length) return false;
    flip.direction = direction;
    flip.target = target;
    prepareFlipTarget(flip);
  }
  flip.distance = Math.max(0, -dy * flip.direction);
  updateFlipPose(flip);
  return true;
}

function landOnFlipTarget(flip) {
  if (pageFlip !== flip) return;
  if (!flip.ready) {
    flip.landWhenReady = true;
    return;
  }
  copyPaper(flip.direction === 1 ? flipUnder : flipFace, art);
  changeMonth(flip.target);
}

function endPageFlip(id, cancelled) {
  const flip = pageFlip;
  if (!flip || flip.id !== id || flip.settling) return;
  if (!flip.direction) {
    resetPageFlip();
    return;
  }
  const quick = flip.distance >= 26 && flip.distance / Math.max(1, Date.now() - flip.time) > .48;
  const commit = !cancelled && (quick || flip.distance >= Math.max(44, flip.height * .19));
  flip.settling = true;
  const alreadyVisible = !flipOverlay.hidden;
  if (alreadyVisible) {
    flipOverlay.dataset.settling = 'true';
    paintFlipPose(flip.direction === 1 ? (commit ? 172 : 0) : (commit ? 0 : 172), 0);
  }
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  pageFlipTimer = setTimeout(() => {
    if (pageFlip !== flip) return;
    if (commit) landOnFlipTarget(flip);
    else resetPageFlip();
  }, alreadyVisible && !reduced ? 280 : 0);
}

if (window.PointerEvent) {
  flipPaper.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !beginPageFlip(event.pointerId, event.clientX, event.clientY)) return;
    if (typeof flipPaper.setPointerCapture === 'function') flipPaper.setPointerCapture(event.pointerId);
  });
  flipPaper.addEventListener('pointermove', event => movePageFlip(event.pointerId, event.clientX, event.clientY));
  flipPaper.addEventListener('pointerup', event => endPageFlip(event.pointerId, false));
  flipPaper.addEventListener('pointercancel', event => endPageFlip(event.pointerId, true));
  flipPaper.addEventListener('lostpointercapture', event => endPageFlip(event.pointerId, true));
} else {
  flipPaper.addEventListener('touchstart', event => {
    const touch = event.changedTouches[0];
    if (event.touches.length === 1 && touch) beginPageFlip(touch.identifier, touch.clientX, touch.clientY);
  }, { passive: true });
  flipPaper.addEventListener('touchmove', event => {
    for (const touch of Array.from(event.changedTouches)) {
      if (movePageFlip(touch.identifier, touch.clientX, touch.clientY) && event.cancelable) event.preventDefault();
    }
  }, { passive: false });
  for (const name of ['touchend', 'touchcancel']) flipPaper.addEventListener(name, event => {
    for (const touch of Array.from(event.changedTouches)) endPageFlip(touch.identifier, name === 'touchcancel');
  });
  flipPaper.addEventListener('mousedown', event => {
    if (event.button === 0 && beginPageFlip('mouse', event.clientX, event.clientY)) event.preventDefault();
  });
  window.addEventListener('mousemove', event => movePageFlip('mouse', event.clientX, event.clientY));
  window.addEventListener('mouseup', () => endPageFlip('mouse', false));
}

let drawnBoxes = [];
async function renderArt() {
  const ticket = ++frame;
  if (photoDraft) {
    const { layer, source } = photoDraft;
    const box = { id: layer.id, x: art.width / 2, y: art.height / 2,
      w: art.width, h: art.height, angle: 0, sourceRatio: source.width / source.height, draft: true };
    drawnBoxes = [box];
    const ctx = art.getContext('2d');
    ctx.clearRect(0, 0, art.width, art.height);
    ctx.save();
    ctx.translate(box.x, box.y);
    drawPhoto(ctx, source, layer, box);
    ctx.restore();
    ctx.save();
    ctx.translate(box.x, box.y);
    const outline = gesture && gesture.eraseStroke;
    if (outline && isLassoStroke(outline)) {
      ctx.lineWidth = Math.max(2, art.width / 150);
      ctx.setLineDash([ctx.lineWidth * 2, ctx.lineWidth]);
      lassoPath(ctx, outline.points, photoFraming(layer, box), false);
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
      ctx.lineDashOffset = ctx.lineWidth * 1.5;
      ctx.strokeStyle = '#234cd4';
      ctx.stroke();
    } else if (photoCropId === layer.id) {
      ctx.lineWidth = Math.max(3, art.width / 130);
      ctx.strokeStyle = '#234cd4';
      const inset = ctx.lineWidth / 2;
      ctx.strokeRect(-box.x + inset, -box.y + inset, box.w - 2 * inset, box.h - 2 * inset);
    }
    ctx.restore();
    $('selection').hidden = true;
    return;
  }
  const boxes = await render(art, current(), month, () => ticket === frame);
  if (!boxes) return;
  if (view === 'read') {
    renderedReadPage = month;
    prefetchPreviewNeighbors();
  }
  drawnBoxes = boxes;
  art.classList.toggle('movable', boxes.length > 0);
  const box = boxes.find(item => item.id === selected);
  const selection = $('selection');
  selection.classList.toggle('crop-active', selected !== null && (photoCropId === selected || photoEraseId === selected));
  selection.hidden = !box || view !== 'edit';
  if (box && view === 'edit') Object.assign(selection.style, {
    width: `${box.w / WIDTH * 100}%`, height: `${box.h / HEIGHT * 100}%`,
    left: `${box.x / WIDTH * 100}%`, top: `${box.y / HEIGHT * 100}%`,
    transform: `translate(-50%, -50%) rotate(${box.angle}deg)`
  });
}

function changeMonth(index) {
  if (photoDraft) return;
  if (index === month || index < COVER_PAGE || index >= projects.length) return;
  resetPageFlip();
  renderedReadPage = null;
  closePhotoPicker();
  photoCropId = null;
  photoEraseId = null;
  month = index;
  if (month === COVER_PAGE) markingDates = false;
  if (markingDates) selectMarkedDay(1);
  selected = null;
  resetCanvasGesture();
  drawUI();
  changed(false);
}

function setView(next) {
  if (photoDraft) return;
  if (next === view) return;
  resetPageFlip();
  renderedReadPage = null;
  closePhotoPicker();
  photoCropId = null;
  photoEraseId = null;
  if (view === 'edit') flipPreviews.clear();
  view = next;
  markingDates = false;
  selected = null;
  resetCanvasGesture();
  $('scene').classList.remove('zoomed');
  $('zoom').textContent = '放大';
  drawUI();
  window.scrollTo(0, 0);
}

function newLayer(fields) {
  return { id: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`, x: 512, y: current().group === 'posters' ? 640 : 480, angle: 0, ...fields };
}

function addLayer(fields) {
  const layer = newLayer(fields);
  current().layers.push(layer);
  selected = layer.id;
  drawLayerPanel();
  changed();
}

function button(label, fn, className = '') {
  const el = document.createElement('button');
  el.type = 'button';
  el.textContent = label;
  if (className) el.className = className;
  el.addEventListener('click', fn);
  return el;
}

function assetGrid(group, onclick, entries = assets[group]) {
  const grid = document.createElement('div');
  grid.className = `asset-grid assets-${group}`;
  entries.forEach((asset, index) => {
    const item = button('', () => onclick(index), 'asset');
    if (group !== 'stickers' && group !== 'edges') {
      const active = group === 'frames'
        ? (current().borderIndex || 0) === index
        : current().group === group && current().template === index;
      item.setAttribute('aria-pressed', String(active));
    }
    const preview = document.createElement(asset.src ? 'img' : 'span');
    if (group === 'frames' && !asset.src) {
      preview.className = 'frame-none';
      preview.setAttribute('aria-hidden', 'true');
      preview.textContent = '—';
    } else if (!asset.src && asset.color) {
      preview.className = 'solid-swatch';
      preview.style.backgroundColor = asset.color;
      preview.setAttribute('aria-hidden', 'true');
    } else {
      preview.loading = 'lazy';
      preview.alt = '';
      if (group === 'stickers' && asset.color) preview.className = 'tintable-sticker-preview';
      preview.src = asset.src;
    }
    const name = document.createElement('span');
    name.textContent = asset.name;
    if (group === 'stickers' || group === 'frames' || group === 'edges') item.title = asset.name;
    item.append(preview, name);
    grid.append(item);
  });
  return grid;
}

function heading(text) {
  const heading = document.createElement('h2');
  heading.textContent = text;
  return heading;
}

function textParagraph(text) {
  const el = document.createElement('p');
  el.className = 'hint';
  el.textContent = text;
  return el;
}

let stickerCategory = '';
let stickerPage = 0;

function stickerPicker() {
  const fragment = document.createDocumentFragment();
  const navigation = document.createElement('div');
  navigation.className = 'sticker-navigation';
  const categories = Array.from(new Set(assets.stickers.map(asset => asset.category)));
  if (!categories.includes(stickerCategory)) stickerCategory = categories[0];
  const categorySelect = document.createElement('select');
  categorySelect.setAttribute('aria-label', '贴纸分类');
  for (const category of categories) {
    const option = document.createElement('option');
    option.value = category;
    const count = assets.stickers.filter(asset => asset.category === category).length;
    option.textContent = category + ' · ' + count;
    categorySelect.appendChild(option);
  }
  categorySelect.value = stickerCategory;

  const pages = document.createElement('div');
  pages.className = 'sticker-pages';
  const previous = button('‹', () => { stickerPage -= 1; showPage(); });
  const next = button('›', () => { stickerPage += 1; showPage(); });
  previous.setAttribute('aria-label', '上一页贴纸');
  next.setAttribute('aria-label', '下一页贴纸');
  const pageNumber = document.createElement('span');
  pageNumber.setAttribute('aria-live', 'polite');
  pages.appendChild(previous);
  pages.appendChild(pageNumber);
  pages.appendChild(next);
  navigation.appendChild(categorySelect);
  navigation.appendChild(pages);
  const content = document.createElement('div');

  function showPage() {
    const pageSize = 8;
    const stickers = assets.stickers.filter(asset => asset.category === stickerCategory);
    const count = Math.ceil(stickers.length / pageSize);
    stickerPage = Math.min(Math.max(0, stickerPage), count - 1);
    const entries = stickers.slice(stickerPage * pageSize, (stickerPage + 1) * pageSize);
    pages.hidden = count <= 1;
    previous.disabled = stickerPage === 0;
    next.disabled = stickerPage + 1 >= count;
    pageNumber.textContent = (stickerPage + 1) + ' / ' + count;
    content.textContent = '';
    content.appendChild(assetGrid('stickers', index => {
      const entry = entries[index];
      const layer = { kind: 'sticker', stickerSrc: entry.src, width: entry.color ? 270 : 225 };
      if (entry.color) layer.color = entry.color;
      addLayer(layer);
      if (entry.color) revealEditor($('layer-fields'));
    }, entries));
  }

  categorySelect.addEventListener('change', () => {
    stickerCategory = categorySelect.value;
    stickerPage = 0;
    showPage();
  });
  showPage();
  fragment.appendChild(navigation);
  fragment.appendChild(content);
  return fragment;
}

const dateMarkColors = [
  ['酒红', '#8C3D50'], ['雾蓝', '#4E6F89'], ['橄榄绿', '#586637']
];
const dateMarkShapes = [['circle', '○ 圈圈'], ['heart', '♡ 爱心'], ['star', '☆ 星星']];
let markingDates = false;
let dateTap = null;
let photoCropId = null;
let photoEraseId = null;
let lassoMode = 'lasso-add';
let markedDay = 1;
let markColor = 0;

function monthCells(index) {
  return {
    start: new Date(2027, index, 1).getDay(),
    count: new Date(2027, index + 1, 0).getDate()
  };
}

function dateGrid(project) {
  return project.dateStyle === 'fineDates' || project.dateStyle === 'inkDates'
    ? { left: .070, column: .143 }
    : { left: .0625, column: .146 };
}

function paintDateMarks(ctx, project, index, width, height) {
  if (!project.dateMarks) return;
  const cells = monthCells(index);
  const grid = dateGrid(project);
  ctx.save();
  ctx.lineWidth = Math.max(2, Math.min(width * .004, height * .012));
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  for (let day = 1; day <= cells.count; day++) {
    const mark = project.dateMarks[day];
    if (!mark || !dateMarkColors[mark.color]) continue;
    const cell = cells.start + day - 1;
    const x = (grid.left + grid.column * (cell % 7) - .5) * width;
    const y = (.237 + .134 * Math.floor(cell / 7) - .5) * height;
    ctx.strokeStyle = dateMarkColors[mark.color][1];
    ctx.beginPath();
    if (mark.shape === 'circle') {
      ctx.ellipse(x, y, width * .046, height * .054, -.09, 0, Math.PI * 2);
    } else {
      const rx = width * .057;
      const ry = height * .063;
      const cx = x;
      const cy = y;
      if (mark.shape === 'heart') {
        ctx.moveTo(cx, cy + ry);
        ctx.bezierCurveTo(cx - rx * 2.15, cy - ry * .35, cx - rx * .82, cy - ry * 1.65, cx, cy - ry * .65);
        ctx.bezierCurveTo(cx + rx * .82, cy - ry * 1.65, cx + rx * 2.15, cy - ry * .35, cx, cy + ry);
      } else if (mark.shape === 'star') {
        for (let i = 0; i < 10; i++) {
          const angle = -Math.PI / 2 + i * Math.PI / 5;
          const radius = i % 2 ? .76 : 1;
          const px = cx + Math.cos(angle) * rx * radius;
          const py = cy + Math.sin(angle) * ry * radius;
          if (i) ctx.lineTo(px, py);
          else ctx.moveTo(px, py);
        }
      } else continue;
      ctx.closePath();
    }
    ctx.stroke();
  }
  ctx.restore();
}

function pickDateAt(location) {
  const box = drawnBoxes.find(entry => entry.id === DATE_LAYER);
  if (!box) return;
  const angle = -box.angle * Math.PI / 180;
  const dx = location.x - box.x;
  const dy = location.y - box.y;
  const x = (dx * Math.cos(angle) - dy * Math.sin(angle)) / box.w + .5;
  const y = (dx * Math.sin(angle) + dy * Math.cos(angle)) / box.h + .5;
  const grid = dateGrid(current());
  const col = Math.round((x - grid.left) / grid.column);
  const row = Math.round((y - .237) / .134);
  const cells = monthCells(month);
  const day = row * 7 + col - cells.start + 1;
  if (col >= 0 && col < 7 && row >= 0 && row < 6 && day >= 1 && day <= cells.count) {
    selectMarkedDay(day);
    drawTool();
  }
}

function selectMarkedDay(day) {
  markedDay = day;
  const mark = (current().dateMarks || {})[day];
  if (mark) markColor = mark.color;
}

function dateMarkPicker() {
  const panel = document.createElement('div');
  panel.className = 'date-mark-picker';
  const controls = document.createElement('div');
  controls.className = 'date-mark-actions';
  const dayInput = document.createElement('select');
  dayInput.setAttribute('aria-label', '要标记的日期');
  const count = monthCells(month).count;
  const marks = current().dateMarks || {};
  for (let day = 1; day <= count; day++) {
    const option = document.createElement('option');
    option.value = day;
    option.textContent = day + ' 日' + (marks[day] ? ' · 已标记' : '');
    dayInput.appendChild(option);
  }
  dayInput.value = markedDay;
  dayInput.addEventListener('change', () => {
    selectMarkedDay(Number(dayInput.value));
    drawTool();
  });
  controls.appendChild(dayInput);
  controls.appendChild(button('完成', () => {
    markingDates = false;
    drawTool();
    drawLayerPanel();
    renderArt();
  }));
  panel.appendChild(controls);

  const shapeRow = document.createElement('div');
  shapeRow.className = 'date-mark-actions';
  for (const [shape, name] of dateMarkShapes) {
    const choice = button(name, () => {
      if (!current().dateMarks) current().dateMarks = {};
      current().dateMarks[markedDay] = { shape, color: markColor };
      drawTool();
      changed();
    });
    choice.setAttribute('aria-pressed', String(!!marks[markedDay] && marks[markedDay].shape === shape));
    shapeRow.appendChild(choice);
  }
  const clear = button('清除', () => {
    delete current().dateMarks[markedDay];
    drawTool();
    changed();
  });
  clear.disabled = !marks[markedDay];
  shapeRow.appendChild(clear);
  panel.appendChild(shapeRow);

  const colorRow = document.createElement('div');
  colorRow.className = 'date-mark-actions';
  dateMarkColors.forEach(([name, color], index) => {
    const choice = button(name, () => {
      markColor = index;
      const existing = (current().dateMarks || {})[markedDay];
      if (existing) {
        existing.color = index;
        changed();
      }
      drawTool();
    });
    choice.style.color = color;
    choice.setAttribute('aria-pressed', String(markColor === index));
    colorRow.appendChild(choice);
  });
  panel.appendChild(colorRow);
  panel.appendChild(textParagraph('点画布上的日期，或从下拉框选择。'));
  return panel;
}

function drawTool() {
  for (const item of $('tools').querySelectorAll('[data-tool]')) item.setAttribute('aria-pressed', String(item.dataset.tool === tool));
  if ($('editor').dataset.tool !== tool) $('editor-content').scrollTop = 0;
  $('editor').dataset.tool = tool;
  const body = $('tool-body');
  body.replaceChildren();
  if (tool === 'text' && markingDates && showsDates(current())) {
    body.appendChild(dateMarkPicker());
    return;
  }
  if (tool === 'layout') {
    const choose = (group, template) => {
      Object.assign(current(), { group, template });
      if (selected === DATE_LAYER && !showsDates(current())) {
        selected = null;
        drawLayerPanel();
      }
      const pressed = body.querySelectorAll('.asset-grid:not(.assets-frames):not(.assets-edges) .asset');
      pressed.forEach(item => item.setAttribute('aria-pressed', 'false'));
      const item = body.querySelector(`.assets-${group}`).children[template];
      item.setAttribute('aria-pressed', 'true');
      updateBoardLabel();
      changed();
    };
    const frames = assetGrid('frames', index => {
      current().borderIndex = index;
      Array.from(frames.children).forEach((choice, i) => choice.setAttribute('aria-pressed', String(i === index)));
      changed();
    });
    const edges = assetGrid('edges', index => {
      addLayer({ kind: 'edge', edgeSrc: assets.edges[index].src, x: WIDTH / 2, y: 76, width: 900 });
    });
    body.append(heading('常规台历'), assetGrid('calendars', index => choose('calendars', index)),
      heading('纯色台历'), assetGrid('solids', index => choose('solids', index)),
      heading('满版海报'), assetGrid('posters', index => choose('posters', index)),
      heading('整圈边框'), frames, heading('单边边框'), edges);
  } else if (tool === 'photo') {
    const actions = document.createElement('div');
    actions.className = 'photo-buttons';
    actions.append(button('＋ 上传照片', () => $('upload').click(), 'outline'));
    body.append(heading('自己的照片'), actions, heading('留白纸片'), paperPicker());
    for (const layer of current().layers.filter(item => item.kind === 'photo')) {
      actions.append(button(layer.name, () => { selected = layer.id; drawLayerPanel(); renderArt(); }));
    }
  } else if (tool === 'sticker') {
    body.appendChild(assets.stickers.length ? stickerPicker() : textParagraph('暂无可用贴纸'));
  } else {
    const form = document.createElement('form');
    form.className = 'text-form';
    const input = document.createElement('input');
    input.placeholder = '输入自定义文字';
    input.setAttribute('aria-label', '自定义文字');
    input.maxLength = 38;
    const submit = document.createElement('button');
    submit.className = 'primary';
    submit.textContent = '添加';
    form.append(input, submit);
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!input.value.trim()) return;
      addLayer({ kind: 'text', text: input.value.trim(), font: 'song', color: '#493021', width: 82 });
      input.value = '';
    });
    if (month === COVER_PAGE) {
      const titles = document.createElement('div');
      titles.className = 'layer-actions';
      for (const [id, name] of [['cover-year', '编辑年份'], ['cover-caption', '编辑副标题']]) {
        const title = current().layers.find(layer => layer.id === id);
        if (!title) continue;
        titles.appendChild(button(name, () => {
          selected = title.id;
          drawLayerPanel();
          renderArt();
        }));
      }
      body.append(heading('封面文字'), form);
      if (titles.childElementCount) body.insertBefore(titles, form);
      return;
    }
    const styles = document.createElement('div');
    styles.className = 'type-options';
    for (const [style, name] of [['ink', '黑墨手写（英文）'], ['wine', '酒红连笔']]) {
      const item = button(name, () => {
        const layer = current().layers.find(layer => layer.id === 'title');
        if (layer) {
          if (layer.style !== style) Object.assign(layer, { style, color: defaultColors[style] });
          selected = layer.id;
          drawTool();
          drawLayerPanel();
          changed();
        } else {
          addLayer({ id: 'title', kind: 'art', style, color: defaultColors[style], width: 650 });
          drawTool();
        }
      });
      const sample = document.createElement('img');
      sample.alt = '';
      sample.src = assets[style][month].src;
      item.setAttribute('aria-pressed', String(current().layers.some(layer => layer.id === 'title' && layer.style === style)));
      item.prepend(sample);
      styles.append(item);
    }
    const dateOptions = document.createElement('div');
    dateOptions.className = 'type-options date-options';
    for (const [style, name] of dateStyles) {
      const item = button(name, () => {
        Object.assign(current(), { dateStyle: style, dateVisible: true });
        selected = DATE_LAYER;
        drawTool();
        drawLayerPanel();
        changed();
        revealEditor($('layer-fields'));
      });
      item.setAttribute('aria-pressed', String(showsDates(current()) && (current().dateStyle || 'dates') === style));
      const sample = document.createElement('img');
      sample.alt = '';
      sample.src = assets[style][month].src;
      item.insertBefore(sample, item.firstChild);
      dateOptions.appendChild(item);
    }
    const dateActions = document.createElement('div');
    dateActions.className = 'layer-actions';
    if (showsDates(current())) {
      dateActions.appendChild(button('标记日期', () => {
        markingDates = true;
        selectMarkedDay(1);
        selected = null;
        resetCanvasGesture();
        drawTool();
        drawLayerPanel();
        renderArt();
        revealEditor($('tool-body'));
      }));
      dateActions.appendChild(button('调整日期位置', () => {
        selected = DATE_LAYER;
        drawLayerPanel();
        renderArt();
        revealEditor($('layer-fields'));
      }));
      dateActions.appendChild(button('隐藏日期', () => {
        current().dateVisible = false;
        markingDates = false;
        if (selected === DATE_LAYER) selected = null;
        drawTool();
        drawLayerPanel();
        changed();
      }));
    } else {
      dateActions.appendChild(button('显示日期', () => {
        current().dateVisible = true;
        selected = DATE_LAYER;
        drawTool();
        drawLayerPanel();
        changed();
      }));
    }
    body.append(heading('日期字样'), dateOptions, dateActions, heading('英文月份艺术字'), styles, heading('自定义文字'), form);
  }
}

let pickerKind = '';
let pickerPhoto = null;
let pickerTrigger = null;

function closePhotoPicker(restoreFocus) {
  if (!pickerKind) return;
  const trigger = pickerTrigger;
  pickerKind = '';
  pickerPhoto = null;
  pickerTrigger = null;
  $('editor').removeAttribute('data-picker');
  $('photo-picker').hidden = true;
  if (restoreFocus && trigger && document.contains(trigger)) trigger.focus();
  fitEditor();
}

function photoSlider(label, value, min, max, onInput) {
  const field = document.createElement('label');
  field.className = 'photo-slider';
  const name = document.createElement('span');
  name.textContent = label;
  const input = document.createElement('input');
  input.type = 'range';
  input.min = min;
  input.max = max;
  input.value = value;
  const output = document.createElement('span');
  output.textContent = input.value;
  input.addEventListener('input', () => {
    output.textContent = input.value;
    onInput(Number(input.value));
  });
  field.appendChild(name);
  field.appendChild(input);
  field.appendChild(output);
  return field;
}

function showPhotoPicker(kind, layer, trigger) {
  pickerKind = kind;
  pickerPhoto = layer.id;
  pickerTrigger = trigger;
  const title = kind === 'filter' ? '选择滤镜' : '选择形状';
  const groups = kind === 'filter' ? photoFilterGroups : [['异形裁切', photoShapes]];
  const currentValue = layer[kind] || (kind === 'filter' ? 'none' : 'rect');
  const options = $('photo-picker-options');
  options.textContent = '';
  $('photo-picker-title').textContent = title;
  $('editor').setAttribute('data-picker', kind);
  $('photo-picker').hidden = false;
  $('editor-content').scrollTop = 0;
  const groupControls = document.createElement('div');
  groupControls.className = 'filter-groups';
  const field = document.createElement('fieldset');
  field.className = 'photo-options';
  function showGroup(index) {
    const [name, choices] = groups[index];
    field.textContent = '';
    field.setAttribute('aria-label', name);
    for (const [value, label] of choices) {
      const choice = button(label, () => {
        const active = activeLayer();
        if (active && active.id === pickerPhoto) active[kind] = value;
        closePhotoPicker();
        drawLayerPanel();
        changed();
        const entry = $('layer-fields').querySelector('[data-photo-kind="' + kind + '"]');
        if (entry && active && (kind === 'shape' || value !== 'none')) showPhotoPicker(kind, active, entry);
        else if (entry) entry.focus();
      });
      choice.setAttribute('aria-pressed', String(value === currentValue));
      field.appendChild(choice);
    }
    Array.from(groupControls.children).forEach((control, i) => control.setAttribute('aria-pressed', String(i === index)));
    fitEditor();
  }
  if (groups.length > 1) {
    groups.forEach(([name], index) => groupControls.appendChild(button(index === 0 ? '通用' : name, () => showGroup(index))));
    options.appendChild(groupControls);
  }
  options.appendChild(field);
  if (kind === 'shape') {
    options.appendChild(photoSlider('边缘羽化', layer.feather || 0, 0, 100, value => {
      layer.feather = value;
      changed();
    }));
  } else if (currentValue !== 'none') {
    options.appendChild(photoSlider('滤镜强度', typeof layer.filterStrength === 'number' ? layer.filterStrength : 100, 0, 100, value => {
      layer.filterStrength = value;
      changed();
    }));
    if (newsPalettes.some(palette => palette.id === currentValue)) {
      options.appendChild(photoSlider('网点大小', layer.dotSize || 100, 45, 225, value => {
        layer.dotSize = value;
        changed();
      }));
    }
  }
  showGroup(Math.max(0, groups.findIndex(group => group[1].some(choice => choice[0] === currentValue))));
  $('close-photo-picker').focus();
  fitEditor();
}
$('close-photo-picker').addEventListener('click', () => closePhotoPicker(true));
$('photo-picker').addEventListener('keydown', event => {
  if (event.key === 'Escape') closePhotoPicker(true);
});

function queuePortraitCutout(draft, label) {
  if (draft.cutoutTimer) clearTimeout(draft.cutoutTimer);
  draft.cuttingOut = true;
  $('confirm-photo-edit').disabled = true;
  label.textContent = '正在识别人像…';
  draft.cutoutTimer = setTimeout(() => {
    if (photoDraft !== draft) return;
    draft.cutoutTimer = null;
    try {
      const strength = draft.layer.cutoutStrength || 50;
      const cutout = calculatePhotoCutout(draft.source, strength);
      if (cutout) {
        draft.layer.cutout = cutout;
        label.textContent = '已更新 · 调低保留更多，调高去除更多';
        changed();
      } else {
        label.textContent = '人像和背景不易区分，试试调整程度或自由裁切';
      }
    } catch (error) {
      label.textContent = '这张照片暂时无法抠图，可用自由裁切';
    } finally {
      draft.cuttingOut = false;
      $('confirm-photo-edit').disabled = false;
    }
  }, 95);
}

function stopPortraitCutout(draft) {
  clearTimeout(draft.cutoutTimer);
  draft.cutoutTimer = null;
  draft.cuttingOut = false;
  $('confirm-photo-edit').disabled = false;
}

function showPortraitCutout(layer) {
  if (!photoDraft || photoDraft.saving) return;
  photoDraft.portraitPanel = true;
  drawLayerPanel();
  const status = $('portrait-cutout-status');
  if (!layer.cutout) queuePortraitCutout(photoDraft, status);
}

function drawLayerPanel() {
  const candidate = activeLayer();
  const layer = candidate && (
    (selected === DATE_LAYER && tool === 'text') ||
    ((candidate.kind === 'photo' || candidate.kind === 'paper') && tool === 'photo') ||
    (candidate.kind === 'sticker' && tool === 'sticker') ||
    (candidate.kind === 'edge' && tool === 'layout') ||
    ((candidate.kind === 'text' || candidate.kind === 'art') && tool === 'text')
  ) ? candidate : null;
  $('layer-panel').hidden = !layer || view !== 'edit';
  $('layer-fields').replaceChildren();
  const isDate = selected === DATE_LAYER && !!layer;
  const order = layerOrder(current());
  const index = order.indexOf(selected);
  for (const [buttonId, action] of layerOrderActions) {
    const control = $(buttonId);
    const towardTop = action === 'up' || action === 'top';
    control.disabled = !layer || index < 0 || (towardTop ? index === order.length - 1 : index === 0);
  }
  $('reset-date').hidden = !isDate;
  $('layer-panel').querySelector('h2').textContent = isDate ? '日期位置' : layer && layer.kind === 'photo' ? '照片效果' : '图层编辑';
  fitEditor();
  if (!layer) return;
  const addField = (title, type, key, colorFallback) => {
    const label = document.createElement('label');
    label.className = 'field';
    label.textContent = title;
    const input = document.createElement('input');
    input.type = type;
    if (type === 'text') input.maxLength = 38;
    const activeBackground = assets[current().group][current().template];
    const suggestedColor = colorFallback || (isDate && defaultDateColor(current())) || activeBackground.ink || '#292524';
    input.value = layer[key] || (type === 'color' ? suggestedColor : '');
    let editing = false;
    input.addEventListener('input', () => {
      layer[key] = input.value;
      if (!editing) recordDesignChange();
      editing = true;
      changed(false);
    });
    const finishEdit = () => {
      if (!editing) return;
      editing = false;
      lastDesign = copyDesign({ projects, coverProject });
    };
    input.addEventListener('change', finishEdit);
    input.addEventListener('blur', finishEdit);
    label.append(input);
    $('layer-fields').append(label);
  };
  if (isDate) {
    addField('日期字色', 'color', 'color');
    return;
  }
  if (layer.kind === 'paper') {
    addField('纸片颜色', 'color', 'color');
    return;
  }
  if (layer.kind === 'photo') {
    if (!photoDraft) {
      $('layer-fields').appendChild(button('编辑照片', () => { void editPlacedPhoto(layer); }, 'outline'));
      return;
    }
    const entry = document.createElement('div');
    entry.className = 'photo-entry';
    if (photoDraft.portraitPanel) {
      const draft = photoDraft;
      const status = textParagraph(layer.cutout ? '已抠出人像 · 滑动调节保留范围' : '优先保留画面中央的人像');
      status.id = 'portrait-cutout-status';
      status.classList.add('photo-crop-hint');
      status.setAttribute('role', 'status');
      const slider = photoSlider('抠图程度', layer.cutoutStrength || 50, 10, 100, strength => {
        layer.cutoutStrength = strength;
        queuePortraitCutout(draft, status);
      });
      slider.classList.add('photo-erase-brush');
      entry.appendChild(slider);
      entry.appendChild(status);
      entry.appendChild(button('恢复原图', () => {
        stopPortraitCutout(draft);
        layer.cutout = null;
        status.textContent = '已恢复原图，调整程度可重新抠图';
        changed();
      }));
      entry.appendChild(button('完成抠图', () => {
        if (draft.cuttingOut) return;
        draft.portraitPanel = false;
        drawLayerPanel();
      }));
      $('layer-fields').appendChild(entry);
      return;
    }
    if (photoEraseId === layer.id) {
      entry.classList.add('photo-free-crop');
      for (const [mode, label] of [['lasso-add', '保留线内'], ['lasso-erase', '裁掉线内']]) {
        const choice = button(label, () => {
          lassoMode = mode;
          resetCanvasGesture();
          drawLayerPanel();
          $('layer-fields').querySelector('[data-crop-brush="' + mode + '"]').focus();
        });
        choice.dataset.cropBrush = mode;
        choice.setAttribute('aria-pressed', String(lassoMode === mode));
        entry.appendChild(choice);
      }
      const undo = button('撤销一笔', () => {
        layer.eraseStrokes.pop();
        drawLayerPanel();
        changed();
      });
      undo.id = 'undo-photo-erase';
      undo.disabled = !(layer.eraseStrokes && layer.eraseStrokes.length);
      const hint = textParagraph(lassoMode === 'lasso-add'
        ? '柳叶笔 · 圈内加入已有画面，松手闭合。'
        : '柳叶笔 · 圈内变透明，松手闭合。');
      hint.classList.add('photo-crop-hint');
      entry.appendChild(hint);
      entry.appendChild(undo);
      entry.appendChild(button('完成裁切', () => {
        photoEraseId = null;
        resetCanvasGesture();
        drawLayerPanel();
        renderArt();
      }));
      $('layer-fields').appendChild(entry);
      return;
    }
    if (photoCropId === layer.id) {
      entry.classList.add('photo-ratio-panel');
      const ratios = document.createElement('div');
      ratios.className = 'photo-ratios';
      ratios.setAttribute('role', 'group');
      ratios.setAttribute('aria-label', '裁剪比例');
      const availableRatios = layer.slotAspect ? [['slot', '模板比例']].concat(cropRatios) : cropRatios;
      for (const [value, name] of availableRatios) {
        const choice = button(name, () => {
          layer.cropRatio = value;
          resizePhotoDraft();
          drawLayerPanel();
          $('layer-fields').querySelector('[data-crop-ratio="' + value + '"]').focus();
          changed();
        });
        choice.dataset.cropRatio = value;
        choice.setAttribute('aria-pressed', String((layer.cropRatio || 'original') === value));
        ratios.appendChild(choice);
      }
      entry.appendChild(ratios);
      const zoom = photoSlider('取景缩放', Math.round(photoCropZoom(layer) * 100), 100, 300, value => {
        layer.cropZoom = value / 100;
        const box = drawnBoxes.find(item => item.id === layer.id);
        if (box) {
          const frame = photoFraming(layer, box);
          layer.cropX = clampCrop(layer.cropX || 0, frame.limitX);
          layer.cropY = clampCrop(layer.cropY || 0, frame.limitY);
        }
        changed();
      });
      zoom.classList.add('photo-crop-zoom');
      entry.appendChild(zoom);
      entry.appendChild(button('完成裁剪', () => {
        photoCropId = null;
        resetCanvasGesture();
        drawLayerPanel();
        renderArt();
      }));
      const hint = textParagraph('选比例后可拖动构图。原比例可先放大再拖。');
      hint.classList.add('photo-crop-hint');
      entry.appendChild(hint);
      $('layer-fields').appendChild(entry);
      return;
    }
    for (const [kind, title, choices] of [
      ['filter', '滤镜', [].concat(...photoFilterGroups.map(group => group[1]))],
      ['shape', '形状', photoShapes]
    ]) {
      const trigger = button(title, () => showPhotoPicker(kind, layer, trigger));
      const value = layer[kind] || choices[0][0];
      const current = choices.find(choice => choice[0] === value);
      const label = document.createElement('small');
      label.textContent = (current ? current[1] : choices[0][1]) + ' ›';
      label.setAttribute('aria-hidden', 'true');
      trigger.dataset.photoKind = kind;
      trigger.appendChild(label);
      entry.appendChild(trigger);
    }
    entry.appendChild(button('裁剪比例', () => {
      photoCropId = layer.id;
      resetCanvasGesture();
      drawLayerPanel();
      renderArt();
    }));
    entry.appendChild(button('自由裁切 · 柳叶笔', () => {
      lassoMode = 'lasso-add';
      photoEraseId = layer.id;
      resetCanvasGesture();
      drawLayerPanel();
      renderArt();
    }));
    entry.appendChild(button(layer.cutout ? '调整人像抠图' : '智能人像抠图', () => showPortraitCutout(layer), 'photo-cutout-action'));
    $('layer-fields').appendChild(entry);
  }
  if (layer.kind === 'text') {
    addField('内容', 'text', 'text');
    const label = document.createElement('label');
    label.className = 'field';
    label.textContent = '字体';
    const menu = document.createElement('select');
    for (const [value, name] of [['song', '宋体'], ['fang', '仿宋']]) {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = name;
      menu.appendChild(option);
    }
    if (!layer.font) {
      const original = document.createElement('option');
      original.value = '';
      original.textContent = '原字体';
      menu.appendChild(original);
    }
    menu.value = layer.font || '';
    menu.addEventListener('change', () => {
      layer.font = menu.value;
      changed();
    });
    label.appendChild(menu);
    $('layer-fields').appendChild(label);
  }
  if (layer.color || layer.kind === 'text') addField(layer.kind === 'sticker' ? '贴纸颜色' : '字色', 'color', 'color');
  if (layer.kind === 'sticker' && assets.stickers.some(asset => asset.src === layer.stickerSrc && asset.color)) {
    const fields = $('layer-fields');
    const label = document.createElement('label');
    label.className = 'field sticker-outline-toggle';
    const toggle = document.createElement('input');
    toggle.type = 'checkbox';
    toggle.checked = !!layer.outline;
    label.appendChild(toggle);
    label.appendChild(document.createTextNode('描边'));
    fields.appendChild(label);
    if (layer.outline) addField('描边颜色', 'color', 'outlineColor', '#000000');
    toggle.addEventListener('change', () => {
      layer.outline = toggle.checked;
      drawLayerPanel();
      fields.querySelector('.sticker-outline-toggle input').focus();
      changed();
    });
  }
}

function pageLabel(index) {
  return index === COVER_PAGE ? '封面' : (index + 1) + '月';
}

function drawMonths() {
  const list = $('months');
  if (!list.childElementCount) {
    for (let index = COVER_PAGE; index < projects.length; index++) {
      list.append(button(pageLabel(index), () => changeMonth(index)));
    }
  }
  const activeIndex = month - COVER_PAGE;
  Array.from(list.children).forEach((item, index) => item.setAttribute('aria-current', String(index === activeIndex)));
  const item = list.children[activeIndex];
  list.scrollLeft = item.offsetLeft - list.children[0].offsetLeft - (list.clientWidth - item.clientWidth) / 2;
  $('prev').disabled = month === COVER_PAGE;
  $('next').disabled = month === projects.length - 1;
}

function updateBoardLabel() {
  $('board-label').textContent = month === COVER_PAGE ? '2027 年台历封面' : current().group === 'posters' ? '2027 年 · 满版海报' : '2027 年台历';
}

const templateDialog = $('template-dialog');
const templateTrigger = $('open-templates');
const templateAllPages = $('template-all-pages');
const templateApplyButton = $('apply-template');
const baseTemplateTab = $('template-base-group');
const monthlyTemplateTab = $('template-monthly-group');
const photoTemplateTab = $('template-photo-group');
let templateChoice = 0;
let activeTemplates = styledTemplates;

function updateTemplateChoice() {
  Array.from($('template-list').children).forEach((card, index) =>
    card.setAttribute('aria-pressed', String(index === templateChoice)));
}

function updateTemplateScope() {
  const monthsOnly = activeTemplates !== styledTemplates;
  $('template-scope-caption').textContent = monthsOnly ? '1–12 月' : '封面和 12 个月';
  templateApplyButton.textContent = templateAllPages.checked
    ? (monthsOnly ? '套用到 12 个月' : '套用到全部页')
    : '套用到本页';
}

function showTemplateGroup(presets) {
  activeTemplates = presets;
  templateChoice = 0;
  baseTemplateTab.setAttribute('aria-pressed', String(presets === styledTemplates));
  monthlyTemplateTab.setAttribute('aria-pressed', String(presets === monthlyTemplates));
  photoTemplateTab.setAttribute('aria-pressed', String(presets === photoTemplates));
  const list = $('template-list');
  list.textContent = '';
  list.scrollTop = 0;
  presets.forEach((preset, index) => {
    const card = button('', () => {
      templateChoice = index;
      updateTemplateChoice();
    }, 'template-card');
    const canvas = document.createElement('canvas');
    canvas.width = 240;
    canvas.height = 360;
    canvas.setAttribute('aria-hidden', 'true');
    const caption = document.createElement('span');
    caption.textContent = preset.name;
    const category = document.createElement('small');
    category.textContent = preset.category;
    card.append(canvas, caption, category);
    list.appendChild(card);
    const page = month;
    const project = composeTemplate(preset, page);
    void render(canvas, project, page).then(boxes => {
      if (boxes && project.photoSlots) paintTemplatePhotoSlots(canvas, project.photoSlots);
    });
  });
  updateTemplateChoice();
  updateTemplateScope();
}

function openTemplates() {
  if (view !== 'edit' || photoDraft || !templateDialog.hidden) return;
  templateAllPages.checked = false;
  $('template-page').textContent = '当前页 · ' + pageLabel(month);
  $('template-groups').hidden = month === COVER_PAGE;
  showTemplateGroup(styledTemplates);
  templateDialog.hidden = false;
  $('template-list').children[0].focus();
}

function closeTemplates() {
  templateDialog.hidden = true;
  templateTrigger.focus();
}

function applyTemplateToPage(preset, project, page) {
  const composed = composeTemplate(preset, page);
  const customLayers = project.layers.filter(layer => !layer.templatePart &&
    !(Object.keys(layer).length === Object.keys(defaultMonthTitle).length &&
      Object.keys(defaultMonthTitle).every(key => defaultMonthTitle[key] === layer[key])));
  const keepsTitle = customLayers.some(layer => layer.id === 'title');
  project.layers = composed.layers.filter(layer => !keepsTitle || layer.id !== 'title').concat(customLayers);
  Object.assign(project, { group: composed.group, template: composed.template });
  if (composed.photoSlots) project.photoSlots = composed.photoSlots;
  else delete project.photoSlots;
  if (preset.monthlyOnly) {
    project.borderIndex = composed.borderIndex;
    project.templateBorderIndex = composed.borderIndex;
  } else if (Number.isInteger(project.templateBorderIndex)) {
    if (project.borderIndex === project.templateBorderIndex) delete project.borderIndex;
    delete project.templateBorderIndex;
  }
  if (!composed.isCover) {
    const key = datePositionKey(composed);
    Object.assign(project, { dateStyle: composed.dateStyle, dateVisible: true, [key]: composed[key] });
    delete project.dateLayerIndex;
  }
}

function applyTemplate() {
  const preset = activeTemplates[templateChoice];
  const allPages = templateAllPages.checked;
  if (allPages) {
    if (!preset.monthlyOnly) applyTemplateToPage(preset, coverProject, COVER_PAGE);
    projects.forEach((project, page) => applyTemplateToPage(preset, project, page));
  } else {
    applyTemplateToPage(preset, current(), month);
  }
  markingDates = false;
  selected = null;
  resetCanvasGesture();
  closeTemplates();
  drawUI();
  changed();
  toast('已套用「' + preset.name + '」' + (allPages ? (preset.monthlyOnly ? '到 12 个月' : '到全部 13 页') : ''));
}

baseTemplateTab.addEventListener('click', () => showTemplateGroup(styledTemplates));
monthlyTemplateTab.addEventListener('click', () => showTemplateGroup(monthlyTemplates));
photoTemplateTab.addEventListener('click', () => showTemplateGroup(photoTemplates));
templateTrigger.addEventListener('click', openTemplates);
$('close-templates').addEventListener('click', closeTemplates);
templateAllPages.addEventListener('change', updateTemplateScope);
templateApplyButton.addEventListener('click', applyTemplate);
templateDialog.addEventListener('click', event => {
  if (event.target === templateDialog) closeTemplates();
});
templateDialog.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeTemplates();
  if (event.key !== 'Tab') return;
  const first = $('close-templates');
  const last = templateApplyButton;
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
});

const designActions = $('design-actions');
const clearPageButton = $('clear-page');
const undoEditButton = $('undo-edit');
const editHistory = [];
let lastDesign = null;
let motionPage = null;

function sameDesign(a, b) {
  if (a === b) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object' || a instanceof Blob || b instanceof Blob) return false;
  const keys = Object.keys(a);
  return keys.length === Object.keys(b).length &&
    keys.every(key => Object.prototype.hasOwnProperty.call(b, key) && sameDesign(a[key], b[key]));
}

function recordDesignChange(page = month) {
  if (!lastDesign) return;
  const now = { coverProject, projects };
  if (sameDesign(now, lastDesign)) return;
  editHistory.push({ design: lastDesign, page });
  if (editHistory.length > 25) editHistory.shift();
  lastDesign = copyDesign(now);
  undoEditButton.disabled = false;
}

function finishMotionHistory() {
  if (motionPage === null || handleDrag) return;
  const page = motionPage;
  motionPage = null;
  recordDesignChange(page);
}

function resetEditSelection() {
  closePhotoPicker();
  markingDates = false;
  photoCropId = null;
  photoEraseId = null;
  selected = null;
  resetCanvasGesture();
}

clearPageButton.addEventListener('click', () => {
  if (photoDraft || view !== 'edit') return;
  resetEditSelection();
  const page = current();
  if (!page.layers.length && !page.borderIndex && !page.photoSlots && !showsDates(page)) return;
  page.layers = [];
  delete page.photoSlots;
  delete page.borderIndex;
  delete page.templateBorderIndex;
  delete page.dateMarks;
  delete page.dateStyle;
  delete page.dateLayerIndex;
  delete page.datePosition;
  delete page.posterDatePosition;
  if (!page.isCover) page.dateVisible = false;
  drawUI();
  changed();
  toast('已清空本页，可以撤回');
});

undoEditButton.addEventListener('click', () => {
  if (photoDraft || view !== 'edit') return;
  handleDrag = null;
  resetEditSelection();
  const entry = editHistory.pop();
  if (!entry) return;
  ({ projects, coverProject } = copyDesign(entry.design));
  month = entry.page;
  lastDesign = entry.design;
  undoEditButton.disabled = editHistory.length === 0;
  drawUI();
  changed(false);
  toast('已撤回上一步');
});


const saveDesign = $('save-design');
const restoreDesign = $('restore-design');
const restoreDialog = $('restore-dialog');
let designCheckpoint = null;
let designBusy = false;

function copyDesign(value) {
  if (Array.isArray(value)) return value.map(copyDesign);
  if (!value || typeof value !== 'object' || value instanceof Blob) return value;
  const copy = {};
  for (const key of Object.keys(value)) copy[key] = copyDesign(value[key]);
  return copy;
}

function setDesignBusy(busy) {
  designBusy = busy;
  saveDesign.disabled = busy;
  restoreDesign.disabled = busy;
}

saveDesign.addEventListener('click', async () => {
  if (designBusy || photoDraft || view !== 'edit') return;
  setDesignBusy(true);
  const snapshot = copyDesign({ projects, coverProject, month });
  designCheckpoint = snapshot;
  try {
    const saved = await writeDesignCheckpoint(snapshot);
    toast(saved === 'partial' ? '台历已保存，临时照片仅能在本次打开期间复原。' :
      saved ? '整本台历已保存' : '已保存到本次编辑，关闭后失效。');
  } catch (error) {
    toast('本机保存失败，本次编辑仍可复原。');
  } finally {
    setDesignBusy(false);
  }
});

restoreDesign.addEventListener('click', async () => {
  if (designBusy || photoDraft || view !== 'edit') return;
  setDesignBusy(true);
  try {
    if (!designCheckpoint) designCheckpoint = await readDesignCheckpoint();
    if (photoDraft || view !== 'edit') return;
    if (!designCheckpoint || !Array.isArray(designCheckpoint.projects) || designCheckpoint.projects.length !== projects.length) {
      toast('还没有可复原的版本，请先点「保存」。');
      return;
    }
    restoreDialog.hidden = false;
    $('cancel-restore').focus();
  } catch (error) {
    toast('读取保存版本失败，请重试。');
  } finally {
    setDesignBusy(false);
  }
});

function closeRestoreDialog() {
  restoreDialog.hidden = true;
  restoreDesign.focus();
}

$('cancel-restore').addEventListener('click', closeRestoreDialog);
$('confirm-restore').addEventListener('click', () => {
  if (restoreDialog.hidden) return;
  closeRestoreDialog();
  closePhotoPicker();
  markingDates = false;
  photoCropId = null;
  photoEraseId = null;
  selected = null;
  resetCanvasGesture();
  applySavedWorkspace(copyDesign(designCheckpoint));
  drawUI();
  changed();
  toast('已复原整本台历');
});
restoreDialog.addEventListener('click', event => {
  if (event.target === restoreDialog) closeRestoreDialog();
});
restoreDialog.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeRestoreDialog();
  if (event.key === 'Tab') {
    event.preventDefault();
    const cancel = $('cancel-restore');
    const confirm = $('confirm-restore');
    (document.activeElement === cancel ? confirm : cancel).focus();
  }
});

function emptyPhotoSlots(project) {
  return (project.photoSlots || []).filter(slot => !project.layers.some(layer => layer.photoSlotId === slot.id));
}

function drawPhotoSlots() {
  const host = $('photo-slots');
  const slots = view === 'edit' && !photoDraft ? emptyPhotoSlots(current()) : [];
  const key = slots.map(slot => slot.id).join('|');
  if (host.dataset.slots === key) return;
  host.dataset.slots = key;
  host.textContent = '';
  for (const slot of slots) {
    const item = button('＋ ' + slot.label, () => openSlotPicker(slot), 'photo-slot');
    item.setAttribute('aria-label', '上传' + slot.label);
    item.dataset.photoSlot = slot.id;
    item.dataset.shape = slot.shape;
    if (slot.bleed) item.dataset.bleed = 'true';
    item.style.left = (slot.x - slot.width / 2) / WIDTH * 100 + '%';
    item.style.top = (slot.y - slot.height / 2) / HEIGHT * 100 + '%';
    item.style.width = slot.width / WIDTH * 100 + '%';
    item.style.height = slot.height / HEIGHT * 100 + '%';
    item.style.color = slot.ink;
    item.style.backgroundColor = slot.wash;
    host.appendChild(item);
  }
}

function paintTemplatePhotoSlots(canvas, slots) {
  const ctx = canvas.getContext('2d');
  ctx.save();
  for (const slot of slots) {
    ctx.save();
    ctx.translate(slot.x, slot.y);
    photoShapePath(ctx, slot.shape, slot.width, slot.height);
    ctx.fillStyle = slot.wash;
    ctx.fill();
    ctx.strokeStyle = slot.ink;
    ctx.lineWidth = 6;
    ctx.setLineDash([22, 15]);
    if (!slot.bleed) ctx.stroke();
    ctx.fillStyle = slot.ink;
    ctx.font = '600 43px "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('＋ ' + slot.label, 0, 0, slot.width * .84);
    ctx.restore();
  }
  ctx.restore();
}

function drawUI() {
  app.dataset.view = view;
  if (photoDraft) app.setAttribute('data-photo-edit', '');
  else app.removeAttribute('data-photo-edit');
  $('photo-edit-actions').hidden = !photoDraft;
  $('confirm-photo-edit').textContent = photoDraft && photoDraft.original ? '保存照片' : '确定放入';
  $('cancel-photo-edit').textContent = photoDraft && photoBatch && photoBatch.files.length ? '跳过' : '取消';
  art.setAttribute('aria-label', photoDraft ? '照片编辑画布' : '当前台历设计');
  $('view-title').textContent = photoDraft ? '编辑照片' : { edit: 'DIY 台历编辑器', read: '电子台历', original: '原图预览' }[view];
  $('back').hidden = view === 'edit';
  $('primary').hidden = view !== 'edit' || !!photoDraft;
  templateTrigger.hidden = view !== 'edit' || !!photoDraft;
  designActions.hidden = templateTrigger.hidden;
  $('editor').hidden = view !== 'edit';
  $('read-panel').hidden = view !== 'read';
  $('original-panel').hidden = view !== 'original';
  updateBoardLabel();
  drawPhotoSlots();
  $('board-page').textContent = (month - COVER_PAGE + 1) + ' / ' + (projects.length + 1);
  drawMonths();
  if (view === 'edit' && !photoDraft) drawTool();
  drawLayerPanel();
  renderArt();
}

function point(event) {
  const rect = art.getBoundingClientRect();
  return { x: (event.clientX - rect.left) / rect.width * art.width, y: (event.clientY - rect.top) / rect.height * art.height };
}

function hit(box, p) {
  const a = -box.angle * Math.PI / 180;
  const dx = p.x - box.x, dy = p.y - box.y;
  return Math.abs(dx * Math.cos(a) - dy * Math.sin(a)) <= box.w / 2 + 12 &&
    Math.abs(dx * Math.sin(a) + dy * Math.cos(a)) <= box.h / 2 + 12;
}

const canvasContacts = new Map();
let gesture = null;
let blankTap = false;
let pendingCanvasSelection = false;

function resetCanvasGesture() {
  canvasContacts.clear();
  dateTap = null;
  pendingCanvasSelection = false;
  gesture = null;
  blankTap = false;
  finishMotionHistory();
}

function selectCanvasLayer(box, deferTools) {
  const id = box ? box.id : null;
  if (id === selected) return;
  photoCropId = null;
  photoEraseId = null;
  selected = id;
  if (deferTools) {
    pendingCanvasSelection = true;
    renderArt();
  } else {
    updateCanvasSelection();
  }
}

function updateCanvasSelection() {
  pendingCanvasSelection = false;
  closePhotoPicker();
  const layer = activeLayer();
  if (layer) {
    const nextTool = layer.kind === 'edge' ? 'layout' :
      (layer.kind === 'photo' || layer.kind === 'paper') ? 'photo' : layer.kind === 'sticker' ? 'sticker' : 'text';
    if (tool !== nextTool) {
      tool = nextTool;
      drawTool();
    }
  }
  drawLayerPanel();
  renderArt();
}

function contactFrame() {
  const points = Array.from(canvasContacts.values());
  const first = points[0];
  if (points.length === 1) return { x: first.x, y: first.y, distance: 0, angle: 0 };
  const second = points[1];
  const dx = second.x - first.x, dy = second.y - first.y;
  return {
    x: (first.x + second.x) / 2, y: (first.y + second.y) / 2,
    distance: Math.hypot(dx, dy), angle: Math.atan2(dy, dx)
  };
}

function beginCanvasTransform() {
  const layer = activeLayer();
  gesture = layer && canvasContacts.size ? {
    id: selected, layer, before: Object.assign({}, layer), start: contactFrame()
  } : null;
}

function eraseAt(location, box, layer, stroke) {
  const angle = -box.angle * Math.PI / 180;
  const dx = location.x - box.x, dy = location.y - box.y;
  const frame = photoFraming(layer, box);
  const x = Math.round(1000 * ((dx * Math.cos(angle) - dy * Math.sin(angle)) - frame.x) / frame.w);
  const y = Math.round(1000 * ((dx * Math.sin(angle) + dy * Math.cos(angle)) - frame.y) / frame.h);
  const points = stroke.points;
  const boundedX = Math.max(0, Math.min(1000, x));
  const boundedY = Math.max(0, Math.min(1000, y));
  if (points.length && Math.hypot(boundedX - points[points.length - 2], boundedY - points[points.length - 1]) < 4) return;
  points.push(boundedX, boundedY);
  if (points.length > 400) {
    stroke.points = points.filter((_, i) => i < 2 || i >= points.length - 2 || Math.floor(i / 2) % 2 === 0);
  }
  changed();
}

function startCanvasContact(id, event) {
  if (view !== 'edit' || (photoDraft && photoDraft.saving) || canvasContacts.size === 2) return false;
  const location = point(event);
  if (markingDates && tool === 'text' && showsDates(current())) {
    if (dateTap) return false;
    dateTap = { id, start: location, location };
    return true;
  }
  if (selected !== null && (selected === photoCropId || selected === photoEraseId)) {
    const box = drawnBoxes.find(entry => entry.id === selected);
    if (canvasContacts.size || !box || !hit(box, location)) return false;
    canvasContacts.set(id, location);
    beginCanvasTransform();
    if (photoEraseId === selected && gesture) {
      const stroke = { mode: lassoMode, points: [] };
      gesture.eraseStroke = stroke;
      eraseAt(location, box, gesture.layer, stroke);
    }
    return true;
  }
  if (photoDraft) return false;
  if (!canvasContacts.size) {
    const hitLayer = drawnBoxes.slice().reverse().find(box => hit(box, location));
    if (hitLayer) selectCanvasLayer(hitLayer, true);
    blankTap = !hitLayer;
  } else {
    blankTap = false;
  }
  canvasContacts.set(id, location);
  if (!blankTap) beginCanvasTransform();
  return true;
}

function limitWidth(layer, width) {
  const dates = selected === DATE_LAYER;
  const text = layer.kind === 'text';
  return Math.max(dates ? 280 : text ? 24 : 80, Math.min(dates ? 952 : text ? 190 : 1200, width));
}

function keepLayerOnPaper(layer) {
  if (selected === DATE_LAYER) keepDateOnPaper(layer);
  else {
    layer.x = Math.max(0, Math.min(WIDTH, layer.x));
    layer.y = Math.max(0, Math.min(HEIGHT, layer.y));
  }
}

function moveCanvasContact(id, event) {
  if (dateTap && dateTap.id === id) {
    dateTap.location = point(event);
    return;
  }
  if (!canvasContacts.has(id)) return;
  canvasContacts.set(id, point(event));
  if (!gesture || gesture.id !== selected || view !== 'edit') return;
  const { layer, before, start } = gesture;
  const next = contactFrame();
  if (gesture.eraseStroke) {
    const box = drawnBoxes.find(entry => entry.id === selected);
    if (box) eraseAt(next, box, layer, gesture.eraseStroke);
    return;
  }
  if (photoCropId === selected && layer.kind === 'photo') {
    const box = drawnBoxes.find(entry => entry.id === selected);
    if (!box) return;
    const dx = next.x - start.x, dy = next.y - start.y;
    const angle = -box.angle * Math.PI / 180;
    const frame = photoFraming(before, box);
    layer.cropX = clampCrop((before.cropX || 0) + (dx * Math.cos(angle) - dy * Math.sin(angle)) / box.w, frame.limitX);
    layer.cropY = clampCrop((before.cropY || 0) + (dx * Math.sin(angle) + dy * Math.cos(angle)) / box.h, frame.limitY);
    changed();
    return;
  }
  const pinching = canvasContacts.size === 2 && start.distance > 1;
  if (canvasContacts.size === 2 && !pinching && next.distance > 1) {
    beginCanvasTransform();
    return;
  }
  let sx = 1, sy = 1, rotation = 0;
  if (pinching) {
    const ratio = next.distance / start.distance;
    layer.width = limitWidth(layer, before.width * ratio);
    sx = sy = layer.width / before.width;
    rotation = next.angle - start.angle;
    layer.angle = ((Number(before.angle || 0) + rotation * 180 / Math.PI + 900) % 360) - 180;
  }
  // Transform the layer around the moving midpoint so it stays under the fingers.
  const local = (before.angle || 0) * Math.PI / 180;
  const dx = before.x - start.x, dy = before.y - start.y;
  const u = (dx * Math.cos(local) + dy * Math.sin(local)) * sx;
  const v = (-dx * Math.sin(local) + dy * Math.cos(local)) * sy;
  const angle = local + rotation;
  layer.x = next.x + u * Math.cos(angle) - v * Math.sin(angle);
  layer.y = next.y + u * Math.sin(angle) + v * Math.cos(angle);
  keepLayerOnPaper(layer);
  changed();
}

function lassoEnclosesArea(points) {
  if (points.length < 6) return false;
  let area = 0;
  for (let i = 0, previous = points.length - 2; i < points.length; previous = i, i += 2) {
    area += points[previous] * points[i + 1] - points[i] * points[previous + 1];
  }
  return Math.abs(area) >= 600;
}

function endCanvasContact(id, cancelled) {
  if (dateTap && dateTap.id === id) {
    const { start, location } = dateTap;
    dateTap = null;
    if (!cancelled && markingDates && Math.hypot(location.x - start.x, location.y - start.y) < 35) pickDateAt(location);
    return;
  }
  if (!canvasContacts.delete(id)) return;
  if (canvasContacts.size) {
    beginCanvasTransform();
  } else {
    if (blankTap && !cancelled) selectCanvasLayer(null);
    if (pendingCanvasSelection) updateCanvasSelection();
    const stroke = gesture && gesture.eraseStroke;
    if (stroke && isLassoStroke(stroke)) {
      if (!cancelled && lassoEnclosesArea(stroke.points)) {
        const layer = gesture.layer;
        if (!layer.eraseStrokes) layer.eraseStrokes = [];
        layer.eraseStrokes.push(stroke);
        const undo = $('undo-photo-erase');
        if (undo) undo.disabled = false;
      }
      changed();
    }
    resetCanvasGesture();
  }
}

if (window.PointerEvent) {
  art.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (startCanvasContact(event.pointerId, event) && typeof art.setPointerCapture === 'function') {
      art.setPointerCapture(event.pointerId);
    }
  });
  window.addEventListener('pointermove', event => moveCanvasContact(event.pointerId, event));
  window.addEventListener('pointerup', event => endCanvasContact(event.pointerId, false));
  ['pointercancel', 'lostpointercapture'].forEach(name => {
    window.addEventListener(name, event => endCanvasContact(event.pointerId, true));
  });
} else {
  art.addEventListener('mousedown', event => { if (event.button === 0) startCanvasContact('mouse', event); });
  window.addEventListener('mousemove', event => moveCanvasContact('mouse', event));
  window.addEventListener('mouseup', () => endCanvasContact('mouse', false));
  art.addEventListener('touchstart', event => {
    if (view !== 'edit') return;
    event.preventDefault();
    for (const touch of Array.from(event.changedTouches)) startCanvasContact(touch.identifier, touch);
  }, { passive: false });
  art.addEventListener('touchmove', event => {
    if ((!canvasContacts.size && !dateTap) || view !== 'edit') return;
    event.preventDefault();
    for (const touch of Array.from(event.changedTouches)) moveCanvasContact(touch.identifier, touch);
  }, { passive: false });
  for (const name of ['touchend', 'touchcancel']) {
    art.addEventListener(name, event => {
      for (const touch of Array.from(event.changedTouches)) endCanvasContact(touch.identifier, name === 'touchcancel');
    });
  }
}

art.addEventListener('keydown', event => {
  if (photoDraft) return;
  const layer = activeLayer();
  if (view !== 'edit' || !layer) return;
  const step = event.shiftKey ? 30 : 6;
  switch (event.key) {
    case 'ArrowLeft': layer.x -= step; break;
    case 'ArrowRight': layer.x += step; break;
    case 'ArrowUp': layer.y -= step; break;
    case 'ArrowDown': layer.y += step; break;
    case '+': case '=': layer.width = limitWidth(layer, layer.width * 1.1); break;
    case '-': layer.width = limitWidth(layer, layer.width / 1.1); break;
    default: return;
  }
  event.preventDefault();
  keepLayerOnPaper(layer);
  changed();
});

let handleDrag = null;

function turnLayer(step) {
  const layer = activeLayer();
  if (view !== 'edit' || !layer) return;
  layer.angle = ((Number(layer.angle || 0) + step + 900) % 360) - 180;
  keepLayerOnPaper(layer);
  changed();
}

function startHandle(event) {
  const kind = event.target.dataset.handle;
  const layer = activeLayer();
  if (!kind || kind === 'delete' || !layer || view !== 'edit' || (event.button !== undefined && event.button !== 0)) return;
  const box = drawnBoxes.find(item => item.id === selected);
  if (!box) return;
  event.preventDefault();
  resetCanvasGesture();
  const p = point(event);
  handleDrag = { id: event.pointerId, kind, layer, selected, box, p, before: Object.assign({}, layer), moved: false };
  if (event.pointerId !== undefined && typeof event.target.setPointerCapture === 'function') {
    event.target.setPointerCapture(event.pointerId);
  }
}

function moveHandle(event) {
  const g = handleDrag;
  if (!g || g.id !== event.pointerId || g.selected !== selected || view !== 'edit') return;
  const p = point(event);
  const dx = p.x - g.p.x, dy = p.y - g.p.y;
  if (!g.moved && Math.hypot(dx, dy) < 7) return;
  g.moved = true;
  const { layer, before, box, kind } = g;
  const angle = (before.angle || 0) * Math.PI / 180;
  if (kind === 'rotate') {
    const a = Math.atan2(g.p.y - before.y, g.p.x - before.x);
    const b = Math.atan2(p.y - before.y, p.x - before.x);
    layer.angle = ((Number(before.angle || 0) + (b - a) * 180 / Math.PI + 900) % 360) - 180;
  } else {
    const c = Math.cos(angle), s = Math.sin(angle);
    const x = c * dx + s * dy, y = -s * dx + c * dy;
    const horizontal = kind === 'left' ? -1 : kind === 'right' ? 1 : 0;
    const vertical = kind === 'top' ? -1 : kind === 'bottom' ? 1 : 0;
    let xShift = 0, yShift = 0;
    if (horizontal || vertical) {
      if (horizontal) {
        const stretch = before.stretchX || 100;
        layer.stretchX = Math.max(30, Math.min(300, stretch * (1 + horizontal * x / box.w)));
        xShift = horizontal * box.w * (layer.stretchX / stretch - 1) / 2;
      } else {
        const stretch = before.stretchY || 100;
        layer.stretchY = Math.max(30, Math.min(300, stretch * (1 + vertical * y / box.h)));
        yShift = vertical * box.h * (layer.stretchY / stretch - 1) / 2;
      }
    } else {
      const side = kind === 'scale-left' ? -1 : 1;
      const ratio = 1 + (side * x * box.w + y * box.h) / (box.w * box.w + box.h * box.h);
      layer.width = limitWidth(layer, before.width * ratio);
      const change = layer.width / before.width - 1;
      xShift = side * box.w * change / 2;
      yShift = box.h * change / 2;
    }
    layer.x = before.x + xShift * c - yShift * s;
    layer.y = before.y + xShift * s + yShift * c;
  }
  keepLayerOnPaper(layer);
  changed();
}

function finishHandle(event, cancelled) {
  const g = handleDrag;
  if (!g || g.id !== event.pointerId) return;
  handleDrag = null;
  if (!cancelled && !g.moved && g.kind === 'rotate' && g.selected === selected) turnLayer(90);
  finishMotionHistory();
}

const controls = $('selection');
if (window.PointerEvent) {
  controls.addEventListener('pointerdown', startHandle);
  window.addEventListener('pointermove', moveHandle);
  window.addEventListener('pointerup', event => finishHandle(event, false));
  window.addEventListener('pointercancel', event => finishHandle(event, true));
  window.addEventListener('lostpointercapture', event => finishHandle(event, true));
} else {
  controls.addEventListener('mousedown', startHandle);
  window.addEventListener('mousemove', moveHandle);
  window.addEventListener('mouseup', event => finishHandle(event, false));
  const handleTouch = (touch, target, event) => ({
    target, pointerId: touch.identifier, clientX: touch.clientX, clientY: touch.clientY,
    preventDefault: () => event.preventDefault()
  });
  controls.addEventListener('touchstart', event => {
    if (event.target.dataset.handle === 'delete') return;
    startHandle(handleTouch(event.changedTouches[0], event.target, event));
  }, { passive: false });
  window.addEventListener('touchmove', event => {
    if (!handleDrag) return;
    event.preventDefault();
    for (const touch of Array.from(event.changedTouches)) moveHandle(handleTouch(touch, event.target, event));
  }, { passive: false });
  for (const name of ['touchend', 'touchcancel']) window.addEventListener(name, event => {
    for (const touch of Array.from(event.changedTouches)) finishHandle(handleTouch(touch, event.target, event), name === 'touchcancel');
  });
}

controls.querySelector('[data-handle="rotate"]').addEventListener('click', event => {
  if (event.detail === 0) turnLayer(90);
});
for (const end of ['scale-left', 'scale-right']) controls.querySelector('[data-handle="' + end + '"]').addEventListener('keydown', event => {
  if (event.key !== '+' && event.key !== '-' && event.key !== '=') return;
  const layer = activeLayer();
  if (!layer || view !== 'edit') return;
  event.preventDefault();
  layer.width = limitWidth(layer, layer.width * (event.key === '-' ? 1 / 1.1 : 1.1));
  keepLayerOnPaper(layer);
  changed();
});

let fitFrame = 0;
function mobilePanelLimit() {
  const workspace = $('scene').closest('.workspace');
  const stage = $('scene').parentElement;
  const editor = $('editor');
  const board = stage.querySelector('.board-top');
  const chrome = board.offsetHeight + stage.querySelector('.month-nav').offsetHeight +
    stage.offsetHeight - stage.clientHeight +
    editor.offsetHeight - $('editor-content').offsetHeight +
    (parseFloat(window.getComputedStyle(editor).marginTop) || 0);
  const canvasSpace = Math.min(86, workspace.clientHeight / 4);
  return Math.max(0, workspace.clientHeight - chrome - canvasSpace);
}

function fitEditor() {
  cancelAnimationFrame(fitFrame);
  fitFrame = requestAnimationFrame(() => {
    if (view === 'read') {
      const viewport = window.visualViewport;
      app.style.setProperty('--read-height', Math.floor(viewport ? viewport.height : window.innerHeight) + 'px');
      const rect = $('scene').getBoundingClientRect();
      const width = Math.max(1, Math.min(430, rect.width - 44, (rect.height - 66) * WIDTH / HEIGHT));
      app.style.setProperty('--read-paper-width', width + 'px');
      return;
    }
    if ((!photoDraft && !window.matchMedia('(max-width: 650px)').matches) || view !== 'edit') {
      app.style.removeProperty('--editor-height');
      app.style.removeProperty('--editor-paper-width');
      return;
    }
    const viewport = window.visualViewport;
    app.style.setProperty('--editor-height', Math.floor(viewport ? viewport.height : window.innerHeight) + 'px');
    if (!photoDraft) {
      const expanded = $('editor').dataset.expanded === 'true';
      app.style.setProperty('--editor-content-height', Math.min(expanded ? 316 : 176, mobilePanelLimit()) + 'px');
    }
    const rect = $('scene').getBoundingClientRect();
    const width = Math.max(1, Math.min(rect.width - 34, (rect.height - 34) * art.width / art.height));
    app.style.setProperty('--editor-paper-width', width + 'px');
  });
}
window.addEventListener('resize', fitEditor);
if (window.visualViewport) window.visualViewport.addEventListener('resize', fitEditor);
if (window.ResizeObserver) new ResizeObserver(fitEditor).observe($('scene'));

function revealEditor(target) {
  fitEditor();
  if (!target || target.hidden) return;
  const content = $('editor-content');
  const area = content.getBoundingClientRect();
  const box = target.getBoundingClientRect();
  if (box.top < area.top || box.bottom > area.bottom) {
    content.scrollTop += box.top - area.top;
  }
}

const editorHandle = $('editor-resize');
const editorPanel = $('editor');
let editorDrag = null;
let handledEditorSwipe = false;

function setEditorHeight(mode) {
  editorPanel.dataset.expanded = String(mode === 'expanded');
  editorPanel.dataset.collapsed = String(mode === 'closed');
  editorHandle.setAttribute('aria-expanded', String(mode !== 'closed'));
  editorHandle.setAttribute('aria-label', mode === 'expanded' ? '收起编辑面板' : '展开编辑面板');
  fitEditor();
}

function startEditorDrag(id, y) {
  if (editorDrag) return;
  handledEditorSwipe = false;
  editorDrag = { id, y, height: $('editor-content').clientHeight };
}

function moveEditorDrag(id, y) {
  if (!editorDrag || editorDrag.id !== id || Math.abs(y - editorDrag.y) < 5) return;
  const viewport = window.visualViewport;
  const height = viewport ? viewport.height : window.innerHeight;
  const limit = window.matchMedia('(max-width: 650px)').matches ? Math.min(316, height * .48, mobilePanelLimit()) : Math.min(500, height * .7);
  editorPanel.dataset.dragging = 'true';
  editorPanel.style.setProperty('--editor-drag-height', Math.max(0, Math.min(limit, editorDrag.height + editorDrag.y - y)) + 'px');
  fitEditor();
}

function cancelEditorDrag() {
  editorDrag = null;
  editorPanel.removeAttribute('data-dragging');
  editorPanel.style.removeProperty('--editor-drag-height');
  fitEditor();
}

function endEditorDrag(id, y) {
  if (!editorDrag || editorDrag.id !== id) return;
  const distance = y - editorDrag.y;
  const remaining = editorDrag.height - distance;
  cancelEditorDrag();
  if (Math.abs(distance) < 24) return;
  handledEditorSwipe = true;
  setEditorHeight(distance < 0 ? 'expanded' : remaining <= 44 || editorPanel.dataset.expanded !== 'true' ? 'closed' : 'compact');
}

editorHandle.addEventListener('click', event => {
  if (handledEditorSwipe && event.detail !== 0) {
    handledEditorSwipe = false;
    return;
  }
  setEditorHeight(editorPanel.dataset.collapsed === 'true' ? 'compact' :
    editorPanel.dataset.expanded === 'true' ? 'closed' : 'expanded');
});

if (window.PointerEvent) {
  editorHandle.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    startEditorDrag(event.pointerId, event.clientY);
    if (typeof editorHandle.setPointerCapture === 'function') editorHandle.setPointerCapture(event.pointerId);
  });
  window.addEventListener('pointermove', event => moveEditorDrag(event.pointerId, event.clientY));
  window.addEventListener('pointerup', event => endEditorDrag(event.pointerId, event.clientY));
  editorHandle.addEventListener('pointercancel', cancelEditorDrag);
} else {
  editorHandle.addEventListener('mousedown', event => {
    if (event.button === 0) startEditorDrag('mouse', event.clientY);
  });
  window.addEventListener('mousemove', event => moveEditorDrag('mouse', event.clientY));
  window.addEventListener('mouseup', event => endEditorDrag('mouse', event.clientY));
  editorHandle.addEventListener('touchstart', event => {
    const touch = event.changedTouches[0];
    if (touch) startEditorDrag(touch.identifier, touch.clientY);
  }, { passive: true });
  editorHandle.addEventListener('touchmove', event => {
    if (editorDrag && event.cancelable) event.preventDefault();
    const touch = Array.from(event.changedTouches).find(item => editorDrag && item.identifier === editorDrag.id);
    if (touch) moveEditorDrag(touch.identifier, touch.clientY);
  }, { passive: false });
  editorHandle.addEventListener('touchend', event => {
    const touch = Array.from(event.changedTouches).find(item => editorDrag && item.identifier === editorDrag.id);
    if (touch) endEditorDrag(touch.identifier, touch.clientY);
  });
  editorHandle.addEventListener('touchcancel', cancelEditorDrag);
}

$('tools').addEventListener('click', event => {
  const item = event.target.closest('[data-tool]');
  if (!item || photoDraft) return;
  if (editorPanel.dataset.collapsed === 'true') setEditorHeight('compact');
  closePhotoPicker();
  markingDates = false;
  photoCropId = null;
  photoEraseId = null;
  tool = item.dataset.tool;
  if (tool === 'photo') {
    const layer = activeLayer();
    if (!layer || (layer.kind !== 'photo' && layer.kind !== 'paper')) {
      const photos = current().layers.filter(layer => layer.kind === 'photo');
      selected = photos.length ? photos[photos.length - 1].id : null;
    }
  }
  drawTool();
  drawLayerPanel();
  renderArt();
  revealEditor($('tool-body'));
});
$('prev').onclick = () => changeMonth(month - 1);
$('next').onclick = () => changeMonth(month + 1);
$('primary').onclick = () => setView('read');
$('open-original').onclick = () => setView('original');
$('back').onclick = () => setView(view === 'original' ? 'read' : 'edit');
$('zoom').onclick = () => { $('zoom').textContent = $('scene').classList.toggle('zoomed') ? '缩小' : '放大'; };
$('deselect').onclick = () => { selected = null; drawLayerPanel(); renderArt(); };
$('reset-date').addEventListener('click', () => {
  if (selected !== DATE_LAYER) return;
  const project = current();
  project[datePositionKey(project)] = Object.assign({}, defaultDatePosition(project), { color: datePosition(project).color });
  drawLayerPanel();
  changed();
});
for (const [buttonId, action] of layerOrderActions) {
  $(buttonId).addEventListener('click', () => {
    if (photoDraft || !moveLayerInOrder(current(), selected, action)) return;
    drawLayerPanel();
    changed();
  });
}
controls.querySelector('[data-handle="delete"]').addEventListener('click', () => {
  const layer = activeLayer();
  if (!layer) return;
  closePhotoPicker();
  if (selected === DATE_LAYER) current().dateVisible = false;
  else {
    const project = current();
    const index = project.layers.findIndex(item => item.id === selected);
    if (index >= 0) {
      if (Number.isInteger(project.dateLayerIndex) && index < dateStackIndex(project)) {
        project.dateLayerIndex = dateStackIndex(project) - 1;
      }
      project.layers.splice(index, 1);
    }
  }
  if (layer.blob) cache.delete(layer.blob);
  selected = null;
  drawLayerPanel();
  drawTool();
  changed();
});

async function preparePhoto(file) {
  const source = await picture(file);
  cache.delete(file);
  if (!source) return null;
  const image = document.createElement('canvas');
  const scale = Math.min(1, 1600 / Math.max(source.width, source.height));
  image.width = Math.max(1, Math.round(source.width * scale));
  image.height = Math.max(1, Math.round(source.height * scale));
  image.getContext('2d').drawImage(source, 0, 0, image.width, image.height);
  return image;
}

function photoLayerImage(layer) {
  return picture(layer.blob);
}

async function storePhotoDraft(draft) {
  const { layer, source } = draft;
  const blob = await new Promise(resolve => source.toBlob(resolve, 'image/webp', .9));
  if (!blob) throw new Error('Photo encoding failed');
  layer.blob = blob;
}

let photoBatch = null;
let photoOpening = false;
let pendingSlotPicker = null;

function openSlotPicker(slot) {
  if (photoDraft || photoOpening || view !== 'edit') return;
  pendingSlotPicker = { target: current(), slot };
  $('slot-upload').click();
}

function resizePhotoDraft() {
  const { layer, source } = photoDraft;
  const ratio = photoAspect(layer, source.width / source.height);
  const limit = Math.min(1200, Math.max(source.width, source.height));
  art.width = Math.max(1, Math.round(limit * Math.min(1, ratio)));
  art.height = Math.max(1, Math.round(limit * Math.min(1, 1 / ratio)));
  fitEditor();
}

function showPhotoDraft(layer, source, target, original) {
  closePhotoPicker();
  resetCanvasGesture();
  photoCropId = null;
  photoEraseId = null;
  markingDates = false;
  photoDraft = { layer, source, target, original };
  selected = layer.id;
  tool = 'photo';
  resizePhotoDraft();
  drawnBoxes = [];
  $('editor-content').scrollTop = 0;
  drawUI();
  fitEditor();
}

function finishPhotoDraft(committed) {
  const draft = photoDraft;
  stopPortraitCutout(draft);
  closePhotoPicker();
  resetCanvasGesture();
  photoCropId = null;
  photoEraseId = null;
  photoDraft = null;
  art.width = WIDTH;
  art.height = HEIGHT;
  drawnBoxes = [];
  selected = committed ? draft.layer.id : draft.original ? draft.original.id : draft.previousSelection;
  $('editor-content').scrollTop = 0;
  drawUI();
  if (committed) changed();
}

async function editPlacedPhoto(layer) {
  if (photoOpening || photoDraft) return;
  const target = current();
  photoOpening = true;
  try {
    const image = await photoLayerImage(layer);
    if (current() !== target || view !== 'edit' || !target.layers.includes(layer) || selected !== layer.id) return;
    if (!image) { toast('照片无法读取。'); return; }
    const draft = Object.assign({}, layer);
    if (layer.eraseStrokes) draft.eraseStrokes = layer.eraseStrokes.map(stroke =>
      Object.assign({}, stroke, { points: stroke.points.slice() }));
    showPhotoDraft(draft, image, target, layer);
  } catch (error) {
    toast('照片无法读取。');
  } finally {
    photoOpening = false;
  }
}

async function nextPhotoDraft() {
  const batch = photoBatch;
  photoOpening = true;
  try {
    while (batch.files.length && current() === batch.target && view === 'edit') {
      const file = batch.files.shift();
      try {
        const source = await preparePhoto(file);
        if (current() !== batch.target || view !== 'edit') break;
        if (!source) throw new Error('Image decoding failed');
        const layer = newLayer({
          kind: 'photo',
          name: file.name,
          width: Math.round(Math.min(560, 630 * source.width / source.height)),
          y: batch.target.group === 'posters' ? 690 : 580
        });
        const slot = batch.slots.shift();
        if (slot && (batch.target.photoSlots || []).some(entry => entry.id === slot.id)) {
          Object.assign(layer, {
            photoSlotId: slot.id, x: slot.x, y: slot.y, width: slot.width,
            cropRatio: slot.ratio || 'slot', slotAspect: slot.width / slot.height, shape: slot.shape
          });
        }
        const previousSelection = selected;
        showPhotoDraft(layer, source, batch.target, null);
        photoDraft.previousSelection = previousSelection;
        return;
      } catch (error) {
        batch.rejected++;
      }
    }
    photoBatch = null;
    if (batch.rejected) toast(batch.rejected + ' 张照片无法读取，可试用 JPG、PNG 或 WebP。');
  } finally {
    photoOpening = false;
  }
}

function placePhotoLayer(project, layer) {
  const slots = project.photoSlots || [];
  const order = slots.findIndex(slot => slot.id === layer.photoSlotId);
  if (order < 0) {
    project.layers.push(layer);
    return;
  }
  // Place the main image below the detail images and existing template lettering.
  const index = project.layers.findIndex(item => {
    const previous = slots.findIndex(slot => slot.id === item.photoSlotId);
    return previous > order || (previous < 0 && item.templatePart);
  });
  if (index < 0) project.layers.push(layer);
  else project.layers.splice(index, 0, layer);
}

function startPhotoBatch(input, slots) {
  const files = Array.from(input.files);
  input.value = '';
  if (!files.length || photoDraft || photoOpening || view !== 'edit') return;
  photoBatch = { files, slots, target: current(), rejected: 0 };
  void nextPhotoDraft();
}

$('upload').addEventListener('change', event =>
  startPhotoBatch(event.target, emptyPhotoSlots(current())));
$('slot-upload').addEventListener('change', event => {
  const selection = pendingSlotPicker;
  pendingSlotPicker = null;
  if (selection && selection.target === current() &&
      emptyPhotoSlots(current()).some(slot => slot.id === selection.slot.id)) {
    startPhotoBatch(event.target, [selection.slot]);
  } else {
    event.target.value = '';
  }
});

$('cancel-photo-edit').addEventListener('click', () => {
  if (!photoDraft || photoDraft.saving) return;
  finishPhotoDraft(false);
  if (photoBatch) void nextPhotoDraft();
});

$('confirm-photo-edit').addEventListener('click', async () => {
  const draft = photoDraft;
  if (!draft || draft.saving || draft.cuttingOut) return;
  draft.saving = true;
  $('confirm-photo-edit').disabled = true;
  $('cancel-photo-edit').disabled = true;
  $('photo-edit-actions').classList.add('saving');
  try {
    if (draft.original) {
      Object.assign(draft.original, draft.layer);
    } else {
      await storePhotoDraft(draft);
      placePhotoLayer(draft.target, draft.layer);
    }
    finishPhotoDraft(true);
    if (draft.layer.sessionOnly) toast('这张照片仅保留在本次编辑，建议完成后保存到相册。');
    if (photoBatch) void nextPhotoDraft();
  } catch (error) {
    toast('照片添加失败，请再试一次。');
  } finally {
    draft.saving = false;
    $('confirm-photo-edit').disabled = false;
    $('cancel-photo-edit').disabled = false;
    $('photo-edit-actions').classList.remove('saving');
  }
});

$('save').onclick = async () => {
  const control = $('save');
  control.disabled = true;
  try {
    const index = month;
    const output = document.createElement('canvas');
    output.width = WIDTH;
    output.height = HEIGHT;
    await render(output, current(), index);
    downloadOriginal(await pngBlob(output), originalName(index));
    toast('已生成 PNG 图片');
  } catch { toast('图片生成失败，请再试一次。'); }
  finally { control.disabled = false; }
};

function pngBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('PNG encoding failed')), 'image/png');
  });
}

function originalName(index) {
  return index === COVER_PAGE ? '纸月-2027-封面.png' : '纸月-2027-' + String(index + 1).padStart(2, '0') + '.png';
}

function downloadOriginal(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

$('export-all').addEventListener('click', async event => {
  const control = event.currentTarget;
  const pages = copyDesign([coverProject].concat(projects));
  const canvas = document.createElement('canvas');
  canvas.width = WIDTH;
  canvas.height = HEIGHT;
  control.disabled = true;
  try {
    const files = [];
    for (let i = 0; i < pages.length; i++) {
      control.textContent = '生成 ' + (i + 1) + '/' + pages.length;
      const index = i + COVER_PAGE;
      await render(canvas, pages[i], index);
      files.push({ name: originalName(index), blob: await pngBlob(canvas) });
    }
    downloadOriginal(await originalsZip(files), '纸月-2027-全部原图.zip');
    toast('已导出 ' + pages.length + ' 张 PNG 原图');
  } catch {
    toast('原图下载失败，请再试一次。');
  } finally {
    control.disabled = false;
    control.textContent = '下载全部原图';
  }
});

function applySavedWorkspace(saved) {
  if (saved && Array.isArray(saved.projects) && saved.projects.length === projects.length) {
    projects = saved.projects.map(project => {
      const restored = Object.assign({}, project, {
        layers: project.layers.filter(layer => (layer.kind !== 'sticker' && layer.kind !== 'edge') || layerAsset(layer, 0))
      });
      if (restored.group === 'posters' && restored.dateVisible === true && !restored.posterDatePosition && restored.datePosition) {
        restored.posterDatePosition = Object.assign({}, restored.datePosition);
      }
      return restored;
    });
    if (saved.coverProject && Array.isArray(saved.coverProject.layers)) {
      const restored = Object.assign({}, saved.coverProject, { isCover: true });
      if (restored.group === 'covers') {
        const preset = coverStyles[restored.template];
        if (preset) {
          const [group, style] = preset;
          restored.group = group;
          restored.template = assets[group].findIndex(asset => asset.coverStyle === style);
        }
      }
      const group = assets[restored.group];
      if (group && group[restored.template] && coverStyles.some(preset => preset[0] === restored.group)) {
        restored.layers = restored.layers.filter(layer =>
          !isUnusedCoverTitle(layer) &&
          ((layer.kind !== 'sticker' && layer.kind !== 'edge') || layerAsset(layer, COVER_PAGE)));
        coverProject = restored;
      }
    }
    month = Number.isInteger(saved.month) && saved.month >= COVER_PAGE && saved.month < projects.length ? saved.month : COVER_PAGE;
  }
}

async function start() {
  try {
    db = await storage();
    const saved = await readDesignRecord('workspace');
    applySavedWorkspace(saved);
  } catch { reportStorage(); }
  lastDesign = copyDesign({ projects, coverProject });
  drawUI();
}
window.addEventListener('pagehide', persist);
void start();
