'use strict';

const popPalettes = [
  { id: 'pop-berry', label: '莓粉柠黄', colors: [[55, 21, 93], [235, 41, 127], [255, 215, 67]] },
  { id: 'pop-aqua', label: '湖蓝薄荷', colors: [[22, 59, 109], [14, 171, 177], [223, 252, 189]] },
  { id: 'pop-orange', label: '橘红奶油', colors: [[86, 19, 49], [246, 103, 33], [255, 237, 159]] },
  { id: 'pop-orchid', label: '紫罗兰粉', colors: [[39, 35, 107], [128, 58, 191], [254, 158, 209]] }
];
const newsPalettes = [
  { id: 'news', label: '经典报纸', paper: '#e4d8bc', ink: '#312a22' },
  { id: 'news-rose', label: '莓红粉纸', paper: '#f8d9d6', ink: '#922045' },
  { id: 'news-blue', label: '靛蓝蓝纸', paper: '#dbe9ff', ink: '#223e94' },
  { id: 'news-green', label: '松绿薄荷', paper: '#d7ebd6', ink: '#235844' },
  { id: 'news-violet', label: '葡萄淡紫', paper: '#eee1fa', ink: '#573173' },
  { id: 'news-amber', label: '焦橙暖黄', paper: '#fbe4b4', ink: '#994515' }
];
const photoFilterGroups = [
  ['艺术滤镜', [['none', '原图'], ['glitch', '故障信号'], ['copy', '粗粒复印'], ['pixel', '像素马赛克'], ['comic', '漫画描边']]],
  ['波普艺术', [['pop', '四色拼图'], ...popPalettes.map(palette => [palette.id, palette.label])]],
  ['报纸网点', newsPalettes.map(palette => [palette.id, palette.label])]
];
const photoShapes = [
  ['rect', '矩形'], ['star', '星星'], ['heart', '爱心'], ['bubble', '对话气泡'],
  ['oval', '椭圆'], ['round', '圆角矩形'], ['flower', '花朵'], ['diamond', '菱形']
];
const cropRatios = [
  ['original', '原比例', 0], ['1:1', '1:1', 1], ['4:5', '4:5', 4 / 5],
  ['3:4', '3:4', 3 / 4], ['2:3', '2:3', 2 / 3],
  ['4:3', '4:3', 4 / 3], ['16:9', '16:9', 16 / 9], ['9:16', '9:16', 9 / 16]
];
const photoEffects = new WeakMap();

function photoAspect(layer, sourceRatio) {
  if (layer.cropRatio === 'slot' && layer.slotAspect > 0) return layer.slotAspect;
  const choice = cropRatios.find(item => item[0] === layer.cropRatio);
  return (choice && choice[2]) || sourceRatio;
}

function photoStretch(layer, axis) {
  return (layer[axis] || 100) / 100;
}

function effectCanvas(width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function photoEffect(image, name, strength = 100, dots = 100) {
  if (!name || name === 'none' || strength <= 0) return image;
  const cached = photoEffects.get(image);
  if (cached && cached.name === name && cached.strength === strength && cached.dots === dots) return cached.canvas;
  const scale = Math.min(1, 900 / Math.max(image.width, image.height));
  const w = Math.max(1, Math.round(image.width * scale));
  const h = Math.max(1, Math.round(image.height * scale));
  const canvas = effectCanvas(w, h);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0, w, h);
  const original = strength < 100 ? ctx.getImageData(0, 0, w, h) : null;
  if (name === 'pixel') {
    const ratio = 26 / Math.max(w, h);
    const tiny = effectCanvas(Math.max(1, Math.round(w * ratio)), Math.max(1, Math.round(h * ratio)));
    tiny.getContext('2d').drawImage(image, 0, 0, tiny.width, tiny.height);
    ctx.clearRect(0, 0, w, h);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(tiny, 0, 0, w, h);
  } else {
    const pixels = ctx.getImageData(0, 0, w, h);
    const input = pixels.data;
    const luminance = new Uint8Array(w * h);
    for (let i = 0; i < luminance.length; i++) {
      const j = i * 4;
      luminance[i] = input[j] * .299 + input[j + 1] * .587 + input[j + 2] * .114;
    }
    const news = newsPalettes.find(palette => palette.id === name);
    const pop = popPalettes.find(palette => palette.id === name);
    if (news) drawNews(ctx, pixels, luminance, w, h, news, dots);
    else if (name === 'pop' || pop) drawPop(ctx, pixels, luminance, w, h, pop);
    else drawPhotoPixels(ctx, pixels, luminance, w, h, name);
  }
  if (original) {
    const result = ctx.getImageData(0, 0, w, h);
    const amount = strength / 100;
    for (let i = 0; i < result.data.length; i++) {
      result.data[i] = original.data[i] + (result.data[i] - original.data[i]) * amount;
    }
    ctx.putImageData(result, 0, 0);
  }
  photoEffects.set(image, { name, strength, dots, canvas });
  return canvas;
}

function drawNews(ctx, pixels, luminance, w, h, palette, dots) {
  const step = Math.max(3, Math.round(Math.max(w, h) / 84 * dots / 100));
  ctx.fillStyle = palette.paper;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = palette.ink;
  for (let y = step / 2; y < h + step; y += step) {
    for (let x = step / 2 + (Math.floor(y / step) % 2) * step / 2; x < w + step; x += step) {
      const index = Math.min(h - 1, Math.floor(y)) * w + Math.min(w - 1, Math.floor(x));
      const radius = Math.sqrt((255 - luminance[index]) / 255) * step * .63;
      if (radius < .25) continue;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  const screen = ctx.getImageData(0, 0, w, h);
  for (let i = 3; i < screen.data.length; i += 4) screen.data[i] = pixels.data[i];
  ctx.putImageData(screen, 0, 0);
}

function drawPop(ctx, pixels, luminance, w, h, single) {
  const output = ctx.createImageData(w, h);
  const splitX = Math.max(1, Math.floor(w / 2)), splitY = Math.max(1, Math.floor(h / 2));
  for (let y = 0; y < h; y++) {
    const bottom = y >= splitY;
    const py = Math.floor((bottom ? (y - splitY) / (h - splitY) : y / splitY) * h);
    for (let x = 0; x < w; x++) {
      const right = x >= splitX;
      const px = Math.floor((right ? (x - splitX) / (w - splitX) : x / splitX) * w);
      const sample = single ? y * w + x : py * w + px;
      const palette = single || popPalettes[(bottom ? 2 : 0) + (right ? 1 : 0)];
      const tone = luminance[sample];
      const ink = palette.colors[tone < 88 ? 0 : tone < 173 ? 1 : 2];
      const i = (y * w + x) * 4;
      output.data[i] = ink[0];
      output.data[i + 1] = ink[1];
      output.data[i + 2] = ink[2];
      output.data[i + 3] = pixels.data[sample * 4 + 3];
    }
  }
  ctx.putImageData(output, 0, 0);
}

function drawPhotoPixels(ctx, pixels, luminance, w, h, name) {
  const data = pixels.data;
  const input = new Uint8ClampedArray(data);
  const offset = Math.max(2, Math.round(w * .012));
  for (let y = 0; y < h; y++) {
    const band = Math.floor(y / Math.max(3, h / 39));
    const shift = band % 8 === 2 ? offset * 4 : band % 9 === 4 ? -offset * 3 : 0;
    for (let x = 0; x < w; x++) {
      const i = y * w + x, j = i * 4;
      if (name === 'glitch') {
        const row = y * w;
        const channel = (dx, n) => input[(row + Math.max(0, Math.min(w - 1, x + dx))) * 4 + n];
        const line = y % 5 === 0 ? .73 : 1;
        data[j] = channel(shift + offset, 0) * line;
        data[j + 1] = channel(shift, 1) * line;
        data[j + 2] = channel(shift - offset, 2);
      } else if (name === 'copy') {
        const grit = ((Math.imul(x + 19, 19349663) ^ Math.imul(y + 31, 83492791)) >>> 0) % 75;
        const value = luminance[i] + grit - 38;
        const ink = value < 89 ? 25 : value < 147 ? 89 : value < 186 ? 184 : 239;
        data[j] = ink; data[j + 1] = ink - 2; data[j + 2] = ink - 7;
      } else {
        const edge = Math.abs(luminance[i] - luminance[y * w + Math.min(w - 1, x + 2)]) +
          Math.abs(luminance[i] - luminance[Math.min(h - 1, y + 2) * w + x]);
        for (let c = 0; c < 3; c++) data[j + c] = edge > 37 ? 24 + c * 3 : Math.round(input[j + c] / 51) * 51;
      }
    }
  }
  ctx.putImageData(pixels, 0, 0);
}

function photoShapePath(ctx, shape, w, h) {
  ctx.beginPath();
  if (!shape || shape === 'rect') {
    ctx.rect(-w / 2, -h / 2, w, h);
    return;
  }
  const point = (x, y) => ctx.lineTo(x * w / 2, y * h / 2);
  const bezier = (a, b, c, d, x, y) => ctx.bezierCurveTo(a*w/2,b*h/2,c*w/2,d*h/2,x*w/2,y*h/2);
  if (shape === 'oval') {
    ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
  } else if (shape === 'star' || shape === 'flower') {
    const count = shape === 'star' ? 10 : 96;
    for (let i = 0; i < count; i++) {
      const a = i * Math.PI * 2 / count;
      const r = shape === 'star' ? (i % 2 ? .45 : 1) : .82 + .18 * Math.cos(a * 6);
      point(Math.sin(a) * r, -Math.cos(a) * r);
    }
  } else if (shape === 'heart') {
    point(0, .94);
    bezier(-.22,.73,-1,.22,-1,-.33);
    bezier(-1,-.93,-.36,-1.08,0,-.55);
    bezier(.36,-1.08,1,-.93,1,-.33);
    bezier(1,.22,.22,.73,0,.94);
  } else if (shape === 'diamond') {
    point(0,-1); point(1,0); point(0,1); point(-1,0);
  } else {
    const bubble = shape === 'bubble';
    const bottom = bubble ? .65 : 1;
    point(-.72,-1);point(.72,-1);bezier(.93,-1,1,-.88,1,-.69);
    point(1,bottom-.31);bezier(1,bottom-.12,.93,bottom,.72,bottom);
    if (bubble) { point(.14,bottom);point(-.47,.99);point(-.36,bottom); }
    point(-.72,bottom);bezier(-.93,bottom,-1,bottom-.12,-1,bottom-.31);
    point(-1,-.69);bezier(-1,-.88,-.93,-1,-.72,-1);
  }
  ctx.closePath();
}

function photoCropZoom(layer) {
  return Math.max(1, Math.min(3, Number(layer.cropZoom) || 1));
}

function clampCrop(offset, limit) {
  return Math.max(-limit, Math.min(limit, offset));
}

function photoFraming(layer, box) {
  const zoom = photoCropZoom(layer);
  const sourceRatio = box.sourceRatio || box.w / box.h;
  const frameRatio = box.w / box.h;
  const stretch = box.draft ? 1 : photoStretch(layer, 'stretchX') / photoStretch(layer, 'stretchY');
  const stretchedRatio = sourceRatio * stretch;
  const ratio = stretchedRatio / frameRatio;
  const w = box.w * Math.max(1, ratio) * zoom;
  const h = box.h * Math.max(1, 1 / ratio) * zoom;
  const limitX = Math.max(0, (w / box.w - 1) / 2);
  const limitY = Math.max(0, (h / box.h - 1) / 2);
  return {
    w, h, limitX, limitY,
    x: clampCrop(Number(layer.cropX) || 0, limitX) * box.w - w / 2,
    y: clampCrop(Number(layer.cropY) || 0, limitY) * box.h - h / 2
  };
}

function isLassoStroke(stroke) {
  return stroke.mode === 'lasso-add' || stroke.mode === 'lasso-keep' || stroke.mode === 'lasso-erase';
}

function lassoPath(ctx, points, frame, closed) {
  ctx.beginPath();
  for (let i = 0; i < points.length; i += 2) {
    const x = frame.x + points[i] * frame.w / 1000;
    const y = frame.y + points[i + 1] * frame.h / 1000;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  if (closed) ctx.closePath();
}

function applyLassoStrokes(ctx, strokes, frame, source) {
  for (const stroke of strokes) {
    ctx.save();
    lassoPath(ctx, stroke.points, frame, true);
    if (stroke.mode === 'lasso-add') {
      ctx.clip('evenodd');
      ctx.drawImage(source, frame.x, frame.y, frame.w, frame.h);
    } else {
      // Older drafts can contain an intersection made with the previous keep tool.
      ctx.globalCompositeOperation = stroke.mode === 'lasso-keep' ? 'destination-in' : 'destination-out';
      ctx.fill('evenodd');
    }
    ctx.restore();
  }
}

let photoComposite;
let photoBrushMask;
let featherMask;
let featherKey;

function featheredPhotoMask(shape, width, height, feather) {
  const key = [shape, width, height, feather].join('/');
  if (featherKey === key) return featherMask;
  featherMask = effectCanvas(width, height);
  featherKey = key;
  const ctx = featherMask.getContext('2d');
  const depth = Math.min(width, height) * feather / 500;
  const passes = 14;
  ctx.translate(width / 2, height / 2);
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 1 / passes;
  for (let i = 0; i < passes; i++) {
    const inset = depth * i / (passes - 1);
    photoShapePath(ctx, shape, width - inset * 2, height - inset * 2);
    ctx.fill();
  }
  return featherMask;
}

function paintPhotoStrokes(ctx, strokes, frame) {
  ctx.save();
  ctx.translate(frame.x, frame.y);
  ctx.scale(frame.w, frame.h);
  for (const stroke of strokes) {
    const keeps = stroke.mode === 'keep';
    ctx.globalCompositeOperation = keeps ? 'source-over' : 'destination-out';
    const points = stroke.points;
    const r = stroke.width / 2;
    ctx.beginPath();
    for (let i = 0; i < points.length; i += 2) {
      const x = points[i] / 1000, y = points[i + 1] / 1000;
      const px = i ? points[i - 2] / 1000 : x;
      const py = i ? points[i - 1] / 1000 : y;
      const angle = i ? Math.atan2(y - py, x - px) : -.65;
      const steps = Math.max(1, Math.ceil(Math.hypot(x - px, y - py) / (r * .46)));
      for (let j = 1; j <= steps; j++) {
        const cx = px + (x - px) * j / steps;
        const cy = py + (y - py) * j / steps;
        if (stroke.tip === 'willow') {
          const dx = Math.cos(angle) * r * 1.42;
          const dy = Math.sin(angle) * r * 1.42;
          const nx = -Math.sin(angle) * r * .78;
          const ny = Math.cos(angle) * r * .78;
          ctx.moveTo(cx - dx, cy - dy);
          ctx.bezierCurveTo(cx - dx * .25 + nx, cy - dy * .25 + ny,
            cx + dx * .25 + nx, cy + dy * .25 + ny, cx + dx, cy + dy);
          ctx.bezierCurveTo(cx + dx * .25 - nx, cy + dy * .25 - ny,
            cx - dx * .25 - nx, cy - dy * .25 - ny, cx - dx, cy - dy);
          ctx.closePath();
        } else {
          ctx.moveTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
          ctx.ellipse(cx, cy, r, keeps || stroke.tip === 'round' ? r : r * .56, angle, 0, Math.PI * 2);
        }
      }
    }
    ctx.fill();
  }
  ctx.restore();
}

function drawPhoto(ctx, image, layer, box) {
  let source = image;
  try {
    source = photoEffect(image, layer.filter,
      typeof layer.filterStrength === 'number' ? layer.filterStrength : 100, layer.dotSize || 100);
  } catch (error) {
    if (error.name !== 'SecurityError') throw error;
  }
  const base = layer.cutout ? photoWithCutout(source, layer.cutout) : source;
  const frame = photoFraming(layer, box);
  const feather = layer.feather || 0;
  const strokes = layer.eraseStrokes || [];
  if (!feather && !strokes.length) {
    photoShapePath(ctx, layer.shape, box.w, box.h);
    ctx.clip();
    ctx.drawImage(base, frame.x, frame.y, frame.w, frame.h);
    return;
  }
  const scale = Math.min(1, 1024 / Math.max(box.w, box.h));
  const width = Math.max(1, Math.round(box.w * scale));
  const height = Math.max(1, Math.round(box.h * scale));
  if (!photoComposite) photoComposite = effectCanvas(width, height);
  if (photoComposite.width !== width) photoComposite.width = width;
  if (photoComposite.height !== height) photoComposite.height = height;
  const local = photoComposite.getContext('2d');
  local.clearRect(0, 0, width, height);
  local.save();
  local.translate(width / 2, height / 2);
  local.scale(width / box.w, height / box.h);
  if (!feather) {
    photoShapePath(local, layer.shape, box.w, box.h);
    local.clip();
  }
  if (layer.cutout || !strokes.length || strokes[0].mode !== 'lasso-add') {
    local.drawImage(base, frame.x, frame.y, frame.w, frame.h);
  }
  const brushStrokes = strokes.filter(stroke => !isLassoStroke(stroke));
  const hasSelection = brushStrokes.some(stroke => stroke.mode === 'keep');
  if (!hasSelection && brushStrokes.length) paintPhotoStrokes(local, brushStrokes, frame);
  if (hasSelection) {
    if (!photoBrushMask) photoBrushMask = effectCanvas(width, height);
    if (photoBrushMask.width !== width) photoBrushMask.width = width;
    if (photoBrushMask.height !== height) photoBrushMask.height = height;
    const mask = photoBrushMask.getContext('2d');
    mask.clearRect(0, 0, width, height);
    mask.save();
    mask.translate(width / 2, height / 2);
    mask.scale(width / box.w, height / box.h);
    paintPhotoStrokes(mask, brushStrokes, frame);
    mask.restore();
    local.save();
    local.setTransform(1, 0, 0, 1, 0, 0);
    local.globalCompositeOperation = 'destination-in';
    local.drawImage(photoBrushMask, 0, 0);
    local.restore();
  }
  applyLassoStrokes(local, strokes.filter(isLassoStroke), frame, source);
  local.restore();
  if (feather) {
    local.save();
    local.globalCompositeOperation = 'destination-in';
    local.drawImage(featheredPhotoMask(layer.shape, width, height, feather), 0, 0);
    local.restore();
  }
  ctx.drawImage(photoComposite, -box.w / 2, -box.h / 2, box.w, box.h);
}
