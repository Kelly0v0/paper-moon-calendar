'use strict';

const cutoutMasks = new WeakMap();

function cutoutDistance(data, offset, color) {
  const r = data[offset] - color[0];
  const g = data[offset + 1] - color[1];
  const b = data[offset + 2] - color[2];
  return Math.sqrt(.29 * r * r + .47 * g * g + .24 * b * b);
}

function estimateBackground(data, width, height, border) {
  const clusters = [];
  for (const index of border) {
    const offset = index * 4;
    if (data[offset + 3] < 24) continue;
    let nearest = null, distance = 22;
    for (const cluster of clusters) {
      const current = cutoutDistance(data, offset, cluster.color);
      if (current < distance) { nearest = cluster; distance = current; }
    }
    const x = index % width, y = Math.floor(index / width);
    const side = (x === 0 ? 1 : 0) | (x === width - 1 ? 2 : 0) |
      (y === 0 ? 4 : 0) | (y === height - 1 ? 8 : 0);
    if (nearest) {
      nearest.count++;
      nearest.sides |= side;
      for (let channel = 0; channel < 3; channel++) {
        nearest.color[channel] += (data[offset + channel] - nearest.color[channel]) / nearest.count;
      }
    } else clusters.push({ color: [data[offset], data[offset + 1], data[offset + 2]], count: 1, sides: side });
  }
  clusters.sort((a, b) => b.count - a.count);
  const important = border.length * .04;
  return clusters.filter(cluster => cluster.count >= important &&
    ((cluster.sides & (cluster.sides - 1)) !== 0 || cluster.count >= important * 2))
    .slice(0, 10).map(cluster => cluster.color);
}

function cutoutNeighbors(index, width, height, visit) {
  const x = index % width;
  if (x > 0) visit(index - 1);
  if (x + 1 < width) visit(index + 1);
  if (index >= width) visit(index - width);
  if (index < width * (height - 1)) visit(index + width);
}

function segmentPhoto(data, width, height, strength = 50) {
  const size = width * height;
  const border = [];
  for (let i = 0; i < size; i++) {
    if (i < width || i >= size - width || i % width === 0 || i % width === width - 1) border.push(i);
  }
  const colors = estimateBackground(data, width, height, border);
  if (!colors.length) return null;
  const similarity = new Float32Array(size);
  for (let i = 0; i < size; i++) {
    let distance = Infinity;
    for (const color of colors) distance = Math.min(distance, cutoutDistance(data, i * 4, color));
    similarity[i] = distance;
  }
  const edgeNoise = border.map(i => similarity[i]).sort((a, b) => a - b);
  const baseline = Math.min(49, Math.max(19, edgeNoise[Math.floor(.7 * edgeNoise.length)] + 13));
  const threshold = Math.min(74, Math.max(9, baseline + (strength - 50) * .58));
  const background = new Uint8Array(size);
  const queue = new Int32Array(size);
  let tail = 0;
  const mark = index => {
    if (!background[index]) {
      background[index] = 1;
      queue[tail++] = index;
    }
  };
  for (const i of border) if (similarity[i] < threshold || data[i * 4 + 3] < 24) mark(i);
  for (let head = 0; head < tail; head++) {
    const i = queue[head], o = i * 4;
    const color = [data[o], data[o + 1], data[o + 2]];
    cutoutNeighbors(i, width, height, next => {
      if (background[next]) return;
      const delta = cutoutDistance(data, next * 4, color);
      const localTolerance = similarity[i] < threshold * .8 ? threshold * 1.42 : threshold;
      if ((similarity[next] < localTolerance && delta < threshold * 1.12) || data[next * 4 + 3] < 24) mark(next);
    });
  }
  if (tail < size * .08 || tail > size * .965) return null;

  const seen = background.slice();
  let best = null, bestScore = 0;
  for (let i = 0; i < size; i++) {
    if (seen[i]) continue;
    let length = 1, score = 0;
    queue[0] = i;
    seen[i] = 1;
    for (let head = 0; head < length; head++) {
      const point = queue[head];
      const x = ((point % width) + .5) / width - .5;
      const y = (Math.floor(point / width) + .5) / height - .5;
      // Prefer a connected subject near the center, with room for a portrait's shoulders.
      score += Math.exp(-3.6 * (x * x + (y + .048) * (y + .048)));
      cutoutNeighbors(point, width, height, next => {
        if (!seen[next]) { seen[next] = 1; queue[length++] = next; }
      });
    }
    if (score > bestScore) { bestScore = score; best = queue.slice(0, length); }
  }
  if (!best || best.length < size * .034 || best.length > size * .9) return null;
  const subject = new Uint8Array(size);
  for (const i of best) subject[i] = 1;
  const result = new Uint8Array(size);
  for (let i = 0; i < size; i++) {
    let nearby = 0, count = 0;
    cutoutNeighbors(i, width, height, next => { nearby += subject[next]; count++; });
    result[i] = subject[i] ? (nearby === count ? 255 : 172 + nearby * 17) : Math.min(68, nearby * 20);
  }
  return result;
}

function encodeCutout(mask) {
  let packed = '';
  for (let i = 0; i < mask.length;) {
    const value = mask[i];
    let count = 1;
    while (count < 255 && i + count < mask.length && mask[i + count] === value) count++;
    packed += String.fromCharCode(count, value);
    i += count;
  }
  return btoa(packed);
}

function calculatePhotoCutout(image, strength) {
  const scale = Math.min(1, 288 / Math.max(image.width, image.height));
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));
  if (width < 8 || height < 8) return null;
  const canvas = effectCanvas(width, height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0, width, height);
  const mask = segmentPhoto(ctx.getImageData(0, 0, width, height).data, width, height, strength);
  return mask ? { width, height, packed: encodeCutout(mask) } : null;
}

function decodePhotoCutout(cutout) {
  const { width, height, packed } = cutout;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 8 || height < 8 ||
    width > 288 || height > 288 || typeof packed !== 'string' || packed.length > width * height * 3) return null;
  let bytes;
  try { bytes = atob(packed); } catch (error) { return null; }
  if (bytes.length % 2) return null;
  const canvas = effectCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const pixels = ctx.createImageData(width, height);
  let offset = 0;
  for (let i = 0; i < bytes.length; i += 2) {
    const count = bytes.charCodeAt(i), value = bytes.charCodeAt(i + 1);
    if (!count || offset + count > width * height) return null;
    for (let j = 0; j < count; j++) pixels.data[(offset++) * 4 + 3] = value;
  }
  if (offset !== width * height) return null;
  ctx.putImageData(pixels, 0, 0);
  return canvas;
}

function photoWithCutout(image, cutout) {
  const cached = cutoutMasks.get(image);
  if (cached && cached.cutout === cutout) return cached.canvas;
  const mask = decodePhotoCutout(cutout);
  if (!mask) return image;
  const canvas = effectCanvas(image.width, image.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0);
  ctx.globalCompositeOperation = 'destination-in';
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(mask, 0, 0, canvas.width, canvas.height);
  cutoutMasks.set(image, { cutout, canvas });
  return canvas;
}
